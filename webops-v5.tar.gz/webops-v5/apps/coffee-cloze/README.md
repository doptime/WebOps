# Coffee Cloze V5 Audit — Corrected Test Scenarios

## Overview

This document records the audit findings for the `coffee_cloze_game.tsx` React component
tested through the WebOps V5 harness (`coffee_cloze_test.go`).

The V5 audit uses browser automation to simulate player interactions, captures telemetry
from the game store, and provides structured hypotheses for LLM verdicting.

## Critical Bugs Fixed in Test Scenarios

### 1. Answer Order Mismatch

**Bug**: `coffeeAnswerOrder` listed items in wrong order.

- **Wrong**: `["cup", "saucer", "hot", "liquid", "beverage", "coffee"]`
- **Correct**: `["cup", "beverage", "saucer", "hot", "liquid", "coffee"]`

The game's `ITEMS` array (line 90-146 of `coffee_cloze_game.tsx`) alternates between
`drag_scene_cloze` and `drag_sentence_cloze` types. Beverage and coffee are sentence
cloze items (Q2 and Q6), not zone-based items.

### 2. Sentence Cloze Items Routed to Non-Existent Zones

**Bug**: `perfectCases()` dispatched beverage and coffee to `zone-beverage-hitarea`
and `zone-coffee-hitarea` — neither of these elements exist in the game DOM.

- **Wrong target**: `zone-beverage-hitarea` (doesn't exist)
- **Correct target**: `sentence-blank` (the sentence blank slot, data-vt-id="sentence-blank")

Sentence cloze items (Q2=beverage, Q6=coffee) have NO `targetZone` field. The player
drags the word card to the sentence blank slot. The game validates `item.target ===
droppedWordId` with no zone comparison.

### 3. Hint Scoring: 70% Not Zero

**Bug**: Test expected `score=0` when hints are used. The game applies a 30% penalty
(0.7 multiplier), NOT a zero-score penalty.

- **Wrong expectation**: `score=0`
- **Actual formula**: `score = base * (1 - 0.3) * (1 - latencyDecay)`
  - `base = 100 × item.level` (level 1 = 100pts, level 2 = 200pts)
  - `hintPenalty = 0.3` when `hintUsed=true` (boolean, NOT cumulative)
  - `latencyDecay` ramps from 0.0 to 0.5 over 2 seconds

**Additional bug**: Test referenced non-existent `attemptScore` field in `Attempt`
interface. The `Attempt` type only has `wordId`, `target`, `hintUsed`, `timeTaken`,
`errorType`, `feedbackKind`.

### 4. Position Errors Cannot Apply to Sentence Cloze

**Bug**: Position error scenarios attempted to test Q2 and Q6 for position errors,
but sentence cloze items have no zone concept — the answer is always correct if
dropped to the sentence blank with the right word.

**Fix**: Q2 (beverage) and Q6 (coffee) in the position error scenario now drag
correctly to `sentence-blank`, yielding 4 position errors (scene cloze only) and
2 correct answers.

### 5. Score Thresholds Were Incorrect

| Scenario | Old Expectation | Corrected Expectation |
|----------|----------------|----------------------|
| Perfect player | score ≥ 600 | score ≥ 400 (max 500) |
| Hint player | score = 0 | score ≥ 300 (≈350) |
| Mixed player | score 300–320 | score 400–480 (≈440) |

The max score is `500` (not 600) because items have different levels:
- Q1 (cup, level 1): 100pts
- Q2 (beverage, level 1): 100pts
- Q3 (saucer, level 1): 100pts
- Q4 (hot, level 2): 200pts
- Q5 (liquid, level 2): 200pts
- Q6 (coffee, level 2): 200pts

## Game Architecture

### Item Types

**`drag_scene_cloze`**: Word card dragged to an SVG zone (hit area).
- Validation: `item.target === droppedWordId && item.targetZone === zoneId`
- Position error: `target === droppedWordId && targetZone !== zoneId`
- Semantic error: `target !== droppedWordId`
- Zones exist: cup, saucer, hot, liquid (SVG `<rect>` with `data-vt-id="zone-*-hitarea"`)

**`drag_sentence_cloze`**: Word card dragged to sentence blank slot.
- Validation: `item.target === droppedWordId` (no zone check)
- No position error possible (single target: sentence blank)
- Items: beverage (Q2), coffee (Q6)

### Scoring

```typescript
function computeScore(base: number, hintUsed: boolean, timeTakenMs: number): number {
  const hintPenalty = hintUsed ? 0.3 : 0.0;
  const latencyDecay = Math.min((timeTakenMs - 1000) / 2000, 0.5);
  return base * (1 - hintPenalty) * (1 - latencyDecay);
}
```

- `base = 100 × item.level`
- `hintUsed` is a boolean flag (second hint click has no additional effect)
- `latencyDecay` starts at 0.0 for 1-second response, ramps to 0.5

### Phase Flow

```
CHOOSING → (drag) → CORRECT | INCORRECT → (next-button / Enter) → next item → COMPLETE
```

- `phase` transitions after drop validation
- `lastFeedbackKind`: `"correct" | "position" | "semantic"`
- `next-button` also activated by keyboard Enter
- After all 6 items, `phase = "COMPLETE"`

### Telemetry & VT-IDs

Key `data-vt-id` attributes used by test scenarios:

| VT-ID | Element | Notes |
|-------|---------|-------|
| `word-card-{id}` | Word card buttons | 3 per question |
| `zone-{id}-hitarea` | SVG zone rects | Scene cloze only |
| `zone-{id}-conceptual` | SVG conceptual zones | Labels only (beverage, coffee) |
| `sentence-blank` | Sentence blank slot | Sentence cloze only |
| `next-button` | HUD button | Advance to next item |
| `hint-button` | HUD button | Reveal answer, 30% score penalty |
| `score-display` | HUD text | Shows current score |
| `game-root` | Root container | Mount point |

## Test Scenarios (Corrected)

### 1. Perfect Player
- 6 correct drags (zone for scene cloze, sentence-blank for sentence cloze)
- Expected: `correctCount=6`, `score ≥ 400`, `reviewQueue=0`, `phase=COMPLETE`

### 2. Position Error Player
- 4 scene cloze items: drag correct word to wrong zone → position errors
- 2 sentence cloze items: drag correct word to sentence-blank → correct
- Expected: `4 position errors`, `correctCount=2`, `score ≥ 100`, `reviewQueue=4`

### 3. Semantic Error Player
- All 6 items: drag wrong word (distractor) → semantic errors
- Expected: `6 semantic errors`, `correctCount=0`, `score=0`, `reviewQueue=6`

### 4. Hint Player
- 6 items: click hint (twice, second click no effect) + drag correct word
- Expected: `all hintUsed=true`, `correctCount=6`, `score ≥ 300`, `reviewQueue=0`

### 5. Mixed Player
- Q1-Q3 correct, Q4 position error, Q5 semantic error, Q6 hint + correct
- Expected: `correctCount=4`, `reviewQueue=2`, `score 400-480`

## LLM Verdicting

Each scenario carries:
- `Hypothesis`: predicted outcome string
- `Intent`: purpose of the scenario
- `Tags`: classification for filtering (happy-path, failure-path, hint-path)

The `batchVerdict` struct captures per-scenario LLM assessments, cross-scenario
findings, root causes, and notes. The `LLMPayload` captures store snapshots and
attempt telemetry for the LLM to evaluate.

## References

- Game source: `coffee_cloze_game.tsx`
- Test source: `coffee_cloze_test.go`
- WebOps library: `WebOps/` (Go builder → JSON IR → browser injection)
