// coffee_cloze_audit.go —— Coffee Cloze 单文件审计程序。
//
// 设计原则:
//   * 单文件自给自足。5 个 JS 场景脚本以 Go 反引号字符串 inline 在本文件,
//     chromedp 编排、CLI、报告器全在一处,无 webops 库依赖。
//   * 不调用 Anthropic API。AgentHarness(oh-my-pi)上层负责 LLM 推理;
//     本程序只产出确定性的结构化报告,着色文本或 JSON 二选一。
//   * 浏览器侧的 window.WebOps.runScript(source, ctx) 由项目根 agent.ts 提供,
//     由游戏前端动态 import 注入,本程序通过 chromedp.Evaluate 直接调用。
//
// 用法:
//   go run coffee_cloze_audit.go -url http://localhost:3001
//   go run coffee_cloze_audit.go -url http://localhost:3001 -json
//   go run coffee_cloze_audit.go -scenarios position-error-player,mixed-player
//
// 退出码:
//   0  审计完整跑完(无论场景 PASS 还是 FAIL)
//   1  -strict 模式下有场景 FAIL
//   2  参数/环境错误,审计未跑
//
// 依赖: github.com/chromedp/chromedp, golang.org/x/sync/errgroup
//
// ============================================================================
// 目录:
//   1. 类型 + 常量
//   2. 游戏意图(供报告头部 / AgentHarness 上下文)
//   3. 内联 JS 场景脚本(perfect / positionError / semanticError / hint / mixed)
//   4. 场景清单 buildScenarios
//   5. chromedp 池
//   6. 单场景执行器 runOneScenario
//   7. 编排 Audit / Close
//   8. CLI 解析
//   9. main + runAuditOnce
//  10. 文本报告
//  11. JSON 报告
//  12. 工具(颜色 / wrap / splitCsv ...)
// ============================================================================

package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/chromedp/chromedp"
	"golang.org/x/sync/errgroup"
)

// ============================================================================
// 1. 类型 + 常量
// ============================================================================

const (
	// auditParam 必须与 runtime.ts 里 shouldEnableWebOps 用的 URL 闸门一致。
	auditParam = "webops=1"
	// 单场景默认 chromedp 总超时;场景内 waitFor 各自有更短的超时。
	defaultScenarioTimeout = 180 * time.Second
	defaultConcurrency     = 4
)

// Scenario 是 Go 端能看到的"场景"全部信息:元数据 + 浏览器要 eval 的 JS。
type Scenario struct {
	ID           string
	Tags         []string
	Intent       string
	Hypothesis   string
	ScriptSource string // inline JS 字符串,会被 agent.ts 的 runScript 用 AsyncFunction 包后执行
}

// AuditRequest 一次 Audit() 调用的输入。
type AuditRequest struct {
	URL         string
	GameIntent  string // 顶层设计意图,只用于报告头部
	Scenarios   []Scenario
	Concurrency int
	Timeout     time.Duration // 单场景超时,0 → defaultScenarioTimeout
}

// AuditResult 全部场景跑完后的输出。无 LLM 判决字段。
type AuditResult struct {
	DurationMs int64            `json:"durationMs"`
	Results    []ScenarioResult `json:"results"`
}

// ScenarioResult 单场景结果。
type ScenarioResult struct {
	ScenarioID string          `json:"scenarioId"`
	Intent     string          `json:"intent,omitempty"`
	Hypothesis string          `json:"hypothesis,omitempty"`
	Tags       []string        `json:"tags,omitempty"`
	Payload    json.RawMessage `json:"payload,omitempty"`    // 浏览器侧 runScript 返回的 JSON 串
	InfraError string          `json:"infraError,omitempty"` // chromedp / 网络 / 脚本启动失败
	DurationMs int64           `json:"durationMs"`
}

// ScenarioPayload 是 agent.ts 里 runV5Script 产出的 payload 形态在 Go 侧的镜像。
// 报告器要解析它才能渲染 expects / actions / reads。
type ScenarioPayload struct {
	ScenarioID   string                 `json:"scenarioId"`
	Intent       string                 `json:"intent,omitempty"`
	Hypothesis   string                 `json:"hypothesis,omitempty"`
	Tags         []string               `json:"tags,omitempty"`
	StartedAt    float64                `json:"startedAt"`
	DurationMs   int                    `json:"durationMs"`
	FinalStore   json.RawMessage        `json:"finalStore,omitempty"`
	Reads        map[string]interface{} `json:"reads"`
	Observations []scenarioObs          `json:"observations"`
	Actions      []scenarioAct          `json:"actions"`
	Errors       []string               `json:"errors"`
	Aborted      string                 `json:"aborted,omitempty"`
}

type scenarioObs struct {
	Name   string  `json:"name"`
	Passed bool    `json:"passed"`
	Ts     float64 `json:"ts"`
	Kind   string  `json:"kind"` // "observe" | "expect" | "wait_for"
	Intent string  `json:"intent,omitempty"`
	Mark   string  `json:"mark,omitempty"`
}

type scenarioAct struct {
	Index   int     `json:"index"`
	Op      string  `json:"op"` // "click" | "drag" | "key" | "wait" | "wait_for"
	StartTs float64 `json:"startTs"`
	EndTs   float64 `json:"endTs"`
	Ok      bool    `json:"ok"`
	Target  string  `json:"target,omitempty"`
	Source  string  `json:"source,omitempty"`
	Key     string  `json:"key,omitempty"`
	Mark    string  `json:"mark,omitempty"`
	Intent  string  `json:"intent,omitempty"`
	Error   string  `json:"error,omitempty"`
}

// ============================================================================
// 2. 游戏意图(报告头部 + AgentHarness 上下文锚)
// ============================================================================

const coffeeClozeExpectations = `Coffee Cloze game expectations:
- 6 vocabulary cloze items, alternating drag_scene_cloze (zone-based) and drag_sentence_cloze (blank-based).
- Scoring: base = 100 × item.level (level 1 = 100pts, level 2 = 200pts). Hint used → ×0.7 (30% penalty). Latency decay up to ×0.5.
- phase: CHOOSING (awaiting drag) → CORRECT | INCORRECT (feedback) → COMPLETE (after all 6 items).
- errorType: null (correct) | "position" (right word, wrong zone — scene cloze only) | "semantic" (wrong word).
- Scene cloze items: drag word card → SVG zone hitArea (cup/saucer/hot/liquid).
- Sentence cloze items (Q2 beverage, Q6 coffee): drag word card → sentence blank slot, no zone concept.
- HUD next-button advances to next item (also Enter key).
- reviewQueue collects all incorrect attempts for spaced repetition.
- Hint (hintUsed=true boolean): clicking hint button reveals answer, applies 30% score penalty. Not cumulative.
`

const gameIntent = "Coffee Cloze: 6 道拖放式 vocabulary cloze 题。" + coffeeClozeExpectations

// ============================================================================
// 3. 内联 JS 场景脚本
//
// 注意: 这些字符串是 JavaScript 代码,会被 agent.ts 里 new AsyncFunction('webops', source)
// 包成一个 async function 后执行。脚本顶层可见全局符号 `webops`(助手对象)和 ES 语法。
//
// 关键约束: Go 反引号字符串不能含字面反引号 → 脚本里所有 JS 模板字符串都改成 "+" 拼接。
// 这是与文件层面的字符串容器适配,JS 语义不变。
//
// IDE 提示: JetBrains 系列识别 "language=JavaScript" 注释开启 JS 高亮。
// ============================================================================

// language=JavaScript
const perfectPlayerScript = `
// happy path: 每题把正确词卡拖到对应位置。期望 6 题全对、score ≥ 400、reviewQueue 空。
await webops.wait(800);
webops.observe("game_root_visible", !!webops.dom("game-root"),
  { intent: "首屏渲染后 game-root 应在 DOM 里" });

for (let i = 0; i < 6; i++) {
  if (!(await webops.waitFor("item_ready",
    () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
    5000))) break;

  const target = webops.state().currentTarget;
  webops.read("q" + (i + 1) + "_target", target);

  const isSentence = target === "beverage" || target === "coffee";
  const drop = isSentence ? "sentence-blank" : "zone-" + target + "-hitarea";
  await webops.drag("word-card-" + target, drop, {
    duration: 500,
    mark: "DRAG_CORRECT_" + target.toUpperCase(),
    intent: "拖正确的词卡 " + target + " 到 " + (isSentence ? "sentence-blank (sentence cloze)" : target + " zone (scene cloze)"),
  });

  await webops.waitFor("feedback_shown",
    () => webops.state().phase === "CORRECT" || webops.state().phase === "INCORRECT",
    3000);
  webops.observe("feedback_is_correct",
    webops.state().lastFeedbackKind === "correct",
    { intent: "正确答题后 lastFeedbackKind 应为 'correct'" });

  await webops.wait(700);
  await webops.click("next-button", { mark: "CLICK_NEXT", intent: "进入下一题" });
  await webops.wait(400);
}

await webops.wait(1500);
webops.read("final_score", webops.state().score);
webops.read("final_phase", webops.state().phase);

webops.expect("reached_complete",
  webops.state().phase === "COMPLETE",
  { intent: "6 题后应进 COMPLETE 状态" });
webops.expect("all_6_attempts",
  webops.state().attemptsCount === 6,
  { intent: "attemptsCount 等于 6" });
webops.expect("all_correct",
  webops.state().correctCount === 6,
  { intent: "correctCount 等于 6 — 全部正确" });
webops.expect("score_at_least_400",
  webops.state().score >= 400,
  { intent: "满分 500 (2 × level1@100 + 4 × level2@200),考虑延迟衰减 ≥ 400" });
webops.expect("review_queue_empty",
  webops.state().reviewQueue.length === 0,
  { intent: "无错题,reviewQueue 应空" });
`

// language=JavaScript
const positionErrorPlayerScript = `
// scene cloze 词拖到错误 zone → errorType='position'。
// sentence cloze (beverage/coffee) 无 zone 概念,只能拖到 sentence-blank,所以仍然正确。
// 期望: 4 个 position error + 2 个 correct, correctCount=2, reviewQueue=4。
const scene = ["cup", "saucer", "hot", "liquid"];
const wrongZoneFor = (t) => scene.includes(t)
  ? "zone-" + scene[(scene.indexOf(t) + 1) % 4] + "-hitarea"
  : null;

await webops.wait(800);

for (let i = 0; i < 6; i++) {
  if (!(await webops.waitFor("item_ready",
    () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
    5000))) break;

  const target = webops.state().currentTarget;
  const isSentence = target === "beverage" || target === "coffee";

  if (isSentence) {
    await webops.drag("word-card-" + target, "sentence-blank", {
      mark: "CORRECT_Q" + (i + 1),
      intent: "q" + (i + 1) + " (" + target + ") sentence cloze → 正确拖到 sentence-blank",
    });
  } else {
    await webops.drag("word-card-" + target, wrongZoneFor(target), {
      mark: "POS_ERR_Q" + (i + 1),
      intent: "q" + (i + 1) + " (" + target + ") 词对位置错 — 拖到 " + wrongZoneFor(target),
    });
  }

  await webops.waitFor("feedback_shown",
    () => webops.state().phase === "CORRECT" || webops.state().phase === "INCORRECT",
    3000);
  if (!isSentence) {
    webops.observe("feedback_is_position",
      webops.state().lastFeedbackKind === "position",
      { intent: "scene cloze 错位 → lastFeedbackKind 应为 'position'" });
  }

  await webops.wait(500);
  await webops.click("next-button", { mark: "NEXT" });
  await webops.wait(400);
}

await webops.wait(1500);
webops.expect("reached_complete", webops.state().phase === "COMPLETE");

const attempts = webops.state().attempts || [];
const positionErrors = attempts.filter(a => a.errorType === "position").length;
webops.expect("scene_cloze_position_errors",
  positionErrors === 4,
  { intent: "4 个 scene cloze 词拖错 zone → errorType='position' 应有 4 条" });

webops.expect("sentence_cloze_correct",
  webops.state().correctCount === 2,
  { intent: "2 个 sentence cloze 词正确 → correctCount=2" });
webops.expect("score_from_correct_items",
  webops.state().score >= 100,
  { intent: "2 个 sentence cloze 正确贡献分数 (level1@100 × 2)" });
webops.expect("review_queue_has_4",
  webops.state().reviewQueue.length === 4,
  { intent: "4 个 position error 进入 reviewQueue" });
`

// language=JavaScript
const semanticErrorPlayerScript = `
// 拖错词卡 → errorType='semantic'。6 题全错, score=0, reviewQueue 6 项。
// 关键: lex !== target,无论 zone 对错都判 semantic error。
const wrongCardFor = (t) => ({
  cup: "liquid", saucer: "beverage", hot: "coffee", liquid: "cup",
  beverage: "cup", coffee: "cup",
})[t];

await webops.wait(800);

for (let i = 0; i < 6; i++) {
  if (!(await webops.waitFor("item_ready",
    () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
    5000))) break;

  const target = webops.state().currentTarget;
  const isSentence = target === "beverage" || target === "coffee";
  const drop = isSentence ? "sentence-blank" : "zone-" + target + "-hitarea";
  const wrongCard = wrongCardFor(target);

  await webops.drag("word-card-" + wrongCard, drop, {
    mark: "SEM_ERR_Q" + (i + 1),
    intent: "q" + (i + 1) + " 实拖 " + wrongCard + " 而非 " + target + " → 语义错",
  });

  await webops.waitFor("feedback_shown",
    () => webops.state().phase === "CORRECT" || webops.state().phase === "INCORRECT",
    3000);
  webops.observe("feedback_is_semantic",
    webops.state().lastFeedbackKind === "semantic",
    { intent: "拖错词 → lastFeedbackKind 应为 'semantic'" });

  await webops.wait(500);
  await webops.click("next-button", { mark: "NEXT" });
  await webops.wait(400);
}

await webops.wait(1500);
webops.expect("reached_complete", webops.state().phase === "COMPLETE");

const attempts = webops.state().attempts || [];
const allSemantic = attempts.length === 6 && attempts.every(a => a.errorType === "semantic");
webops.expect("all_6_semantic", allSemantic,
  { intent: "6 题全部 errorType='semantic'" });
webops.expect("zero_correct",
  webops.state().correctCount === 0,
  { intent: "无任何正确,correctCount=0" });
webops.expect("zero_score",
  webops.state().score === 0,
  { intent: "无任何正确,score=0" });
webops.expect("review_queue_full_6",
  webops.state().reviewQueue.length === 6,
  { intent: "6 题全错 → reviewQueue 6 项" });
`

// language=JavaScript
const hintPlayerScript = `
// 每题点 2 次 hint(第二次无额外效果),然后拖正确词。
// hintUsed=true 是布尔不累计,分数打 0.7 折。期望 6 题全对, score ≥ 300。
await webops.wait(800);

for (let i = 0; i < 6; i++) {
  if (!(await webops.waitFor("item_ready",
    () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
    5000))) break;

  await webops.click("hint-button", {
    mark: "HINT1",
    intent: "首次提示 → hintUsed=true, 30% 分数惩罚",
  });
  await webops.wait(300);
  await webops.click("hint-button", {
    mark: "HINT2",
    intent: "第二次提示应无额外效果 (hintUsed 已为 true)",
  });
  await webops.wait(300);

  const target = webops.state().currentTarget;
  const isSentence = target === "beverage" || target === "coffee";
  const drop = isSentence ? "sentence-blank" : "zone-" + target + "-hitarea";
  await webops.drag("word-card-" + target, drop, {
    duration: 500,
    mark: "DRAG_CORRECT_" + target.toUpperCase(),
    intent: "hint 后拖正确词 " + target,
  });

  await webops.waitFor("feedback_shown",
    () => webops.state().phase === "CORRECT" || webops.state().phase === "INCORRECT",
    3000);

  await webops.wait(500);
  await webops.click("next-button", { mark: "NEXT" });
  await webops.wait(400);
}

await webops.wait(1500);
webops.expect("reached_complete", webops.state().phase === "COMPLETE");

const attempts = webops.state().attempts || [];
const allHintUsed = attempts.length === 6 && attempts.every(a => a.hintUsed === true);
webops.expect("all_hint_used", allHintUsed,
  { intent: "6 题全 hintUsed=true" });
webops.expect("all_correct_logical",
  webops.state().correctCount === 6,
  { intent: "hint 用了但拖对了,仍计入 correctCount" });
webops.expect("score_is_70_percent",
  webops.state().score >= 300,
  { intent: "满分 500 × 0.7 = 350 (30% 提示惩罚)" });
webops.expect("review_queue_empty",
  webops.state().reviewQueue.length === 0,
  { intent: "全部拖对 → reviewQueue 空 (即使用了 hint)" });
`

// language=JavaScript
const mixedPlayerScript = `
// q1-q3 全对, q4 position 错, q5 semantic 错, q6 hint 后对。
// 期望: correctCount=4 (q1-q3 + q6), reviewQueue=2 (q4, q5), score ∈ [400, 480]。
const scene = ["cup", "saucer", "hot", "liquid"];
const wrongZoneFor = (t) => scene.includes(t)
  ? "zone-" + scene[(scene.indexOf(t) + 1) % 4] + "-hitarea"
  : "zone-cup-hitarea";
const wrongCardFor = (t) => ({
  cup: "liquid", saucer: "beverage", hot: "coffee", liquid: "cup",
  beverage: "saucer", coffee: "hot",
})[t];

async function dragCorrect(mark, intent) {
  const target = webops.state().currentTarget;
  const isSentence = target === "beverage" || target === "coffee";
  const drop = isSentence ? "sentence-blank" : "zone-" + target + "-hitarea";
  await webops.drag("word-card-" + target, drop, {
    duration: 500,
    mark: mark || ("DRAG_CORRECT_" + target.toUpperCase()),
    intent: intent || ("拖正确词 " + target),
  });
}

async function nextQuestion(mark) {
  await webops.waitFor("feedback_shown",
    () => webops.state().phase === "CORRECT" || webops.state().phase === "INCORRECT",
    3000);
  await webops.wait(500);
  await webops.click("next-button", { mark });
  await webops.wait(400);
}

await webops.wait(800);
webops.read("q_idx_initial", webops.state().attemptsCount);

// q1-q3: 全部正确
for (let i = 0; i < 3; i++) {
  if (!(await webops.waitFor("item_ready",
    () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
    5000))) break;
  await dragCorrect(null, "q" + (i + 1) + " 正确");
  await nextQuestion("MIXED_NEXT_CORRECT");
}

// q4: position 错
if (await webops.waitFor("q4_ready",
  () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
  5000)) {
  const target = webops.state().currentTarget;
  const isSentence = target === "beverage" || target === "coffee";
  const drop = isSentence ? "zone-cup-hitarea" : wrongZoneFor(target);
  await webops.drag("word-card-" + target, drop, {
    mark: "MIX_POS",
    intent: "q4 位置错 — 词对但 zone 错",
  });
  await nextQuestion("MIXED_NEXT_Q4");
}

// q5: semantic 错
if (await webops.waitFor("q5_ready",
  () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
  5000)) {
  const target = webops.state().currentTarget;
  const isSentence = target === "beverage" || target === "coffee";
  const drop = isSentence ? "sentence-blank" : "zone-" + target + "-hitarea";
  await webops.drag("word-card-" + wrongCardFor(target), drop, {
    mark: "MIX_SEM",
    intent: "q5 语义错 — 拖 " + wrongCardFor(target) + " 而非 " + target,
  });
  await nextQuestion("MIXED_NEXT_Q5");
}

// q6: hint 后正确
if (await webops.waitFor("q6_ready",
  () => webops.state().phase === "CHOOSING" && webops.state().currentTarget !== "none",
  5000)) {
  await webops.click("hint-button", { mark: "MIX_HINT", intent: "q6 用提示" });
  await webops.wait(400);
  await dragCorrect("MIX_HINT_CORRECT", "q6 hint 后拖正确");
  await nextQuestion("MIXED_NEXT_Q6");
}

await webops.wait(1500);

webops.expect("reached_complete", webops.state().phase === "COMPLETE");
webops.expect("attempts_eq_6", webops.state().attemptsCount === 6);
webops.expect("correct_eq_4",
  webops.state().correctCount === 4,
  { intent: "q1-q3 三题对 + q6 hint+对 → correctCount=4" });
webops.expect("reviewQ_eq_2",
  webops.state().reviewQueue.length === 2,
  { intent: "q4 + q5 两题进 reviewQueue" });

const score = webops.state().score;
webops.expect("score_in_range",
  score >= 400 && score <= 480,
  { intent: "3 题正确 (300) + q6 hint+正确 (140) ≈ 440; 当前 score=" + score });
`

// ============================================================================
// 4. 场景清单
// ============================================================================

func buildScenarios() []Scenario {
	return []Scenario{
		{
			ID:           "perfect-player",
			Tags:         []string{"happy-path"},
			Intent:       "验证按 currentTarget 正确拖放的 happy path",
			Hypothesis:   "每次正确拖 → +100 或 +200,无 reviewQueue 入队,6 题后 phase=COMPLETE 且 correctCount=6",
			ScriptSource: perfectPlayerScript,
		},
		{
			ID:           "position-error-player",
			Tags:         []string{"failure-path", "position-error"},
			Intent:       "验证 scene cloze 词的 classifyError lex===target & zone!==target 分支",
			Hypothesis:   "4 个 position error (scene cloze), 2 个正确 (sentence cloze), correctCount=2, reviewQueue 长度 4",
			ScriptSource: positionErrorPlayerScript,
		},
		{
			ID:           "semantic-error-player",
			Tags:         []string{"failure-path", "semantic-error"},
			Intent:       "验证 classifyError 的 lex!==target 分支",
			Hypothesis:   "6 题全 errorType='semantic',correctCount=0,score=0,reviewQueue 6 项",
			ScriptSource: semanticErrorPlayerScript,
		},
		{
			ID:           "hint-player",
			Tags:         []string{"happy-path", "hint-path"},
			Intent:       "验证 hint 触发后分数打 7 折, 但仍算 correct",
			Hypothesis:   "6 题全 hintUsed=true, score ≈350 (500 × 0.7), correctCount=6, reviewQueue 空",
			ScriptSource: hintPlayerScript,
		},
		{
			ID:           "mixed-player",
			Tags:         []string{"happy-path", "failure-path", "hint-path"},
			Intent:       "验证多种类型错答与 hint 共存时的累计行为",
			Hypothesis:   "前 3 题正确 (300), q4 position, q5 semantic, q6 hint+correct (140)。correctCount=4, reviewQueue=2, score≈440",
			ScriptSource: mixedPlayerScript,
		},
	}
}

// ============================================================================
// 5. chromedp 池
// ============================================================================

var (
	sharedAllocCtx context.Context
	sharedCancel   context.CancelFunc
	sharedOnce     sync.Once
	sem            chan struct{}
)

func ensureBrowser(concurrency int) {
	sharedOnce.Do(func() {
		if concurrency <= 0 {
			concurrency = defaultConcurrency
		}
		opts := append(chromedp.DefaultExecAllocatorOptions[:],
			chromedp.Flag("headless", true),
			chromedp.Flag("disable-gpu", true),
			chromedp.Flag("no-sandbox", true),
			chromedp.Flag("disable-dev-shm-usage", true),
		)
		sharedAllocCtx, sharedCancel = chromedp.NewExecAllocator(context.Background(), opts...)
		sem = make(chan struct{}, concurrency)
		log.Printf("[audit] shared browser pool ready, concurrency=%d", concurrency)
	})
}

// closePool 释放共享 chromedp 进程。defer 调用,幂等。
func closePool() {
	if sharedCancel != nil {
		sharedCancel()
		sharedCancel = nil
	}
}

// applyAuditParam 在 URL 上加上闸门参数;必须与 runtime.ts shouldEnableWebOps 一致。
func applyAuditParam(rawURL string) string {
	parts := strings.SplitN(auditParam, "=", 2)
	key := parts[0]
	val := "1"
	if len(parts) == 2 {
		val = parts[1]
	}
	u, err := url.Parse(rawURL)
	if err != nil {
		sep := "?"
		if strings.Contains(rawURL, "?") {
			sep = "&"
		}
		return rawURL + sep + auditParam
	}
	q := u.Query()
	q.Set(key, val)
	u.RawQuery = q.Encode()
	return u.String()
}

// ============================================================================
// 6. 单场景执行器
//
// 协议契约(由 agent.ts 提供 window.WebOps.runScript 实现):
//   window.WebOps.runScript(source: string, ctx: object): Promise<string>
//   - source 是 JS 代码体,会被 new AsyncFunction('webops', source) 包成 async 函数
//   - ctx = { scenarioId, intent, hypothesis, tags }
//   - 返回 JSON 字符串(V5Payload)
// ============================================================================

func runOneScenario(ctx context.Context, pageURL string, scenario Scenario, perScenarioTimeout time.Duration) (json.RawMessage, error) {
	if perScenarioTimeout <= 0 {
		perScenarioTimeout = defaultScenarioTimeout
	}
	if scenario.ScriptSource == "" {
		return nil, fmt.Errorf("scenario %q: empty ScriptSource", scenario.ID)
	}

	// 并发度限流
	select {
	case sem <- struct{}{}:
	case <-ctx.Done():
		return nil, ctx.Err()
	}
	defer func() { <-sem }()

	// 每场景独立 tab,storage / cookie / window 隔离
	bctx, cancelB := chromedp.NewContext(sharedAllocCtx)
	defer cancelB()

	// 阶段 1: navigate + 轮询 runScript 注入完成
	navCtx, cancelNav := context.WithTimeout(bctx, 30*time.Second)
	defer cancelNav()
	if err := chromedp.Run(navCtx,
		chromedp.Navigate(applyAuditParam(pageURL)),
		chromedp.Poll(
			`typeof window.WebOps === 'object' && typeof window.WebOps.runScript === 'function'`,
			nil,
		),
	); err != nil {
		return nil, fmt.Errorf("navigate / wait runScript: %w", err)
	}

	// 阶段 2: 序列化脚本源码 + ctx 元字段,调 runScript
	srcLiteral, err := json.Marshal(scenario.ScriptSource)
	if err != nil {
		return nil, fmt.Errorf("marshal script source: %w", err)
	}
	ctxLiteral, err := json.Marshal(map[string]any{
		"scenarioId": scenario.ID,
		"intent":     scenario.Intent,
		"hypothesis": scenario.Hypothesis,
		"tags":       scenario.Tags,
	})
	if err != nil {
		return nil, fmt.Errorf("marshal scenario ctx: %w", err)
	}

	runCtx, cancelRun := context.WithTimeout(bctx, perScenarioTimeout)
	defer cancelRun()

	// chromedp.Evaluate 默认 awaitPromise=true + returnByValue=true,
	// 所以 Promise<string> 会被 await 后以字符串形态返回。
	expr := fmt.Sprintf(`window.WebOps.runScript(%s, %s)`, string(srcLiteral), string(ctxLiteral))
	var payloadStr string
	if err := chromedp.Run(runCtx, chromedp.Evaluate(expr, &payloadStr)); err != nil {
		return nil, fmt.Errorf("evaluate runScript: %w", err)
	}
	return json.RawMessage(payloadStr), nil
}

// ============================================================================
// 7. 编排
// ============================================================================

// Audit 并行跑全部 scenarios(受 req.Concurrency 限流),收集结果。
// 不调任何 LLM。InfraError 字段在单场景失败时填充;一个场景失败不会让批次中断。
// 调用方须 defer closePool() 释放 chromedp 进程。
func Audit(ctx context.Context, req AuditRequest) (*AuditResult, error) {
	if req.URL == "" {
		return nil, fmt.Errorf("audit: URL required")
	}
	if len(req.Scenarios) == 0 {
		return nil, fmt.Errorf("audit: at least one scenario required")
	}
	conc := req.Concurrency
	if conc <= 0 {
		conc = defaultConcurrency
	}
	ensureBrowser(conc)

	startedAt := time.Now()
	results := make([]ScenarioResult, len(req.Scenarios))

	g, gctx := errgroup.WithContext(ctx)
	for i, s := range req.Scenarios {
		i, s := i, s
		g.Go(func() error {
			t0 := time.Now()
			res := ScenarioResult{
				ScenarioID: s.ID,
				Hypothesis: s.Hypothesis,
				Intent:     s.Intent,
				Tags:       s.Tags,
			}
			payload, err := runOneScenario(gctx, req.URL, s, req.Timeout)
			res.DurationMs = time.Since(t0).Milliseconds()
			if err != nil {
				res.InfraError = err.Error()
			} else {
				res.Payload = payload
			}
			results[i] = res
			return nil // 永不让 group 失败 — 一个场景的 infra 错不传染其他
		})
	}
	_ = g.Wait()

	return &AuditResult{
		DurationMs: time.Since(startedAt).Milliseconds(),
		Results:    results,
	}, nil
}

// ============================================================================
// 8. CLI
// ============================================================================

type cliConfig struct {
	URL         string
	Scenarios   string // CSV 子集,空表示全跑
	Concurrency int
	Timeout     time.Duration
	NoColor     bool
	JSON        bool
	Strict      bool
}

func parseFlags() cliConfig {
	cfg := cliConfig{}
	flag.StringVar(&cfg.URL, "url", "http://localhost:3001", "Coffee Cloze game URL")
	flag.StringVar(&cfg.Scenarios, "scenarios", "", "Comma-separated scenario IDs (default: all 5)")
	flag.IntVar(&cfg.Concurrency, "concurrency", defaultConcurrency, "Parallel tabs")
	flag.DurationVar(&cfg.Timeout, "timeout", 10*time.Minute, "Overall audit timeout")
	flag.BoolVar(&cfg.NoColor, "no-color", false, "Disable ANSI color output")
	flag.BoolVar(&cfg.JSON, "json", false, "Emit machine-readable JSON to stdout instead of text report")
	flag.BoolVar(&cfg.Strict, "strict", false, "Exit non-zero if any scenario FAILs (any expect failed)")
	flag.Parse()

	useColor = !cfg.NoColor && os.Getenv("NO_COLOR") == "" && isTerminal()
	if cfg.JSON {
		useColor = false
	}
	return cfg
}

// isTerminal 简单粗暴地探测 stdout 是不是 tty。AgentHarness 一般是 pipe,会返回 false。
func isTerminal() bool {
	fi, err := os.Stdout.Stat()
	if err != nil {
		return false
	}
	return (fi.Mode() & os.ModeCharDevice) != 0
}

// ============================================================================
// 9. main + 单轮 audit
// ============================================================================

func main() {
	cfg := parseFlags()
	exitCode := runSingleAudit(cfg)
	os.Exit(exitCode)
}

func runSingleAudit(cfg cliConfig) int {
	ctx, cancel := context.WithTimeout(context.Background(), cfg.Timeout)
	defer cancel()
	defer closePool()

	result, err := runAuditOnce(ctx, cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, col("error: "+err.Error(), cRed+cBold))
		return 2
	}

	// 解析每个场景的 payload(用于 verdict 派生与报告渲染)
	parsed := make([]*ScenarioPayload, len(result.Results))
	for i, r := range result.Results {
		if len(r.Payload) == 0 {
			continue
		}
		var p ScenarioPayload
		if err := json.Unmarshal(r.Payload, &p); err == nil {
			parsed[i] = &p
		}
	}

	if cfg.JSON {
		printJSONReport(cfg, result, parsed)
	} else {
		printTextReport(cfg, result, parsed)
	}

	if cfg.Strict {
		for i, r := range result.Results {
			if r.InfraError != "" {
				return 1
			}
			if parsed[i] != nil && deriveStatus(parsed[i], r.InfraError) == "FAIL" {
				return 1
			}
		}
	}
	return 0
}

func runAuditOnce(ctx context.Context, cfg cliConfig) (*AuditResult, error) {
	all := buildScenarios()
	if cfg.Scenarios != "" {
		want := map[string]bool{}
		for _, id := range splitCsv(cfg.Scenarios) {
			want[id] = true
		}
		filtered := make([]Scenario, 0, len(all))
		for _, sc := range all {
			if want[sc.ID] {
				filtered = append(filtered, sc)
			}
		}
		if len(filtered) == 0 {
			return nil, fmt.Errorf("no scenarios match: %s", cfg.Scenarios)
		}
		all = filtered
	}

	req := AuditRequest{
		URL:         cfg.URL,
		GameIntent:  gameIntent,
		Scenarios:   all,
		Concurrency: cfg.Concurrency,
	}
	return Audit(ctx, req)
}

// deriveStatus 从 payload 本地派生场景状态。不调任何外部服务。
//   - INFRA_FAIL: chromedp / 网络 / 启动失败
//   - ABORTED:    脚本主动 webops.abort(...)
//   - FAIL:       任一 expect 失败,或脚本运行时报错
//   - PARTIAL:    有非 expect 类 observation 失败(observe / wait_for)
//   - PASS:       全部 expect 通过且无运行时错
func deriveStatus(p *ScenarioPayload, infraError string) string {
	if infraError != "" {
		return "INFRA_FAIL"
	}
	if p == nil {
		return "INFRA_FAIL"
	}
	if p.Aborted != "" {
		return "ABORTED"
	}
	for _, o := range p.Observations {
		if o.Kind == "expect" && !o.Passed {
			return "FAIL"
		}
	}
	if len(p.Errors) > 0 {
		return "FAIL"
	}
	for _, o := range p.Observations {
		if !o.Passed {
			return "PARTIAL"
		}
	}
	return "PASS"
}

// ============================================================================
// 10. 文本报告
// ============================================================================

func printTextReport(cfg cliConfig, result *AuditResult, parsed []*ScenarioPayload) {
	fmt.Println(col("┌─ Coffee Cloze Audit ──────────────────────────────────────────────", cBold))
	fmt.Printf("  URL          %s\n", cfg.URL)
	fmt.Printf("  scenarios    %s\n", ifEmpty(cfg.Scenarios, "(all 5)"))
	fmt.Printf("  concurrency  %d\n", cfg.Concurrency)
	fmt.Printf("  duration     %dms\n", result.DurationMs)
	fmt.Println(col("└────────────────────────────────────────────────────────────────────", cBold))
	fmt.Println()

	fmt.Println(col("Game intent:", cDim))
	for _, line := range strings.Split(strings.TrimSpace(gameIntent), "\n") {
		fmt.Printf("  %s\n", col(line, cDim))
	}
	fmt.Println()

	// 索引重排,场景按字母顺序输出,稳定可读
	type indexed struct {
		i int
		r ScenarioResult
		p *ScenarioPayload
	}
	rows := make([]indexed, len(result.Results))
	for i, r := range result.Results {
		rows[i] = indexed{i, r, parsed[i]}
	}
	sort.Slice(rows, func(a, b int) bool { return rows[a].r.ScenarioID < rows[b].r.ScenarioID })

	passCount, failCount, partialCount, infraCount, abortedCount := 0, 0, 0, 0, 0
	for _, row := range rows {
		status := deriveStatus(row.p, row.r.InfraError)
		switch status {
		case "PASS":
			passCount++
		case "FAIL":
			failCount++
		case "PARTIAL":
			partialCount++
		case "INFRA_FAIL":
			infraCount++
		case "ABORTED":
			abortedCount++
		}
		printScenario(row.r, row.p, status)
	}

	fmt.Println(col("Summary:", cBold))
	fmt.Printf("  total:    %d\n", len(rows))
	if passCount > 0 {
		fmt.Printf("  %s     %d\n", col("PASS", cGreen), passCount)
	}
	if partialCount > 0 {
		fmt.Printf("  %s  %d\n", col("PARTIAL", cYellow), partialCount)
	}
	if failCount > 0 {
		fmt.Printf("  %s     %d\n", col("FAIL", cRed), failCount)
	}
	if infraCount > 0 {
		fmt.Printf("  %s %d\n", col("INFRA_FAIL", cMagenta), infraCount)
	}
	if abortedCount > 0 {
		fmt.Printf("  %s  %d\n", col("ABORTED", cMagenta), abortedCount)
	}
	fmt.Println()
}

func printScenario(r ScenarioResult, p *ScenarioPayload, status string) {
	statusColored := col(fmt.Sprintf("%-11s", status), verdictColor(status))
	fmt.Printf("%s %s %s\n",
		col("▌", verdictColor(status)),
		statusColored,
		col(r.ScenarioID, cBold))
	if r.Intent != "" {
		fmt.Printf("  %s %s\n", col("intent:    ", cDim), wrap(r.Intent, 78))
	}
	if r.Hypothesis != "" {
		fmt.Printf("  %s %s\n", col("hypothesis:", cDim), wrap(r.Hypothesis, 78))
	}
	fmt.Printf("  %s %dms\n", col("duration:  ", cDim), r.DurationMs)

	if r.InfraError != "" {
		fmt.Printf("  %s %s\n", col("infra:     ", cDim), col(r.InfraError, cRed))
		fmt.Println()
		return
	}
	if p == nil {
		fmt.Println()
		return
	}

	// expects / observations
	var expects, observes []scenarioObs
	for _, o := range p.Observations {
		if o.Kind == "expect" {
			expects = append(expects, o)
		} else if o.Kind == "observe" {
			observes = append(observes, o)
		}
	}
	actionOk, actionTotal := 0, len(p.Actions)
	for _, a := range p.Actions {
		if a.Ok {
			actionOk++
		}
	}
	fmt.Printf("  %s actions=%d/%d  observations=%d  expects=%d  reads=%d  errors=%d\n",
		col("counts:    ", cDim),
		actionOk, actionTotal, len(observes), len(expects), len(p.Reads), len(p.Errors))

	if len(expects) > 0 {
		fmt.Printf("  %s\n", col("expects:", cDim))
		for _, e := range expects {
			tick := col("✓", cGreen)
			if !e.Passed {
				tick = col("✗", cRed)
			}
			line := fmt.Sprintf("    %s %s", tick, e.Name)
			if e.Intent != "" {
				line += col("  — "+e.Intent, cDim)
			}
			fmt.Println(line)
		}
	}

	var failedObserves []scenarioObs
	for _, o := range observes {
		if !o.Passed {
			failedObserves = append(failedObserves, o)
		}
	}
	if len(failedObserves) > 0 {
		fmt.Printf("  %s\n", col("failed observations:", cDim))
		for _, o := range failedObserves {
			label := o.Name
			if o.Intent != "" {
				label += col("  — "+o.Intent, cDim)
			}
			fmt.Printf("    %s %s\n", col("✗", cRed), label)
		}
	}

	if len(p.Errors) > 0 {
		fmt.Printf("  %s\n", col("errors:", cDim))
		for _, e := range p.Errors {
			fmt.Printf("    %s %s\n", col("!", cRed), wrap(e, 76))
		}
	}

	if len(p.Reads) > 0 {
		fmt.Printf("  %s\n", col("reads:", cDim))
		// 排序 key 输出可重复结果
		keys := make([]string, 0, len(p.Reads))
		for k := range p.Reads {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			v := p.Reads[k]
			b, _ := json.Marshal(v)
			fmt.Printf("    %s = %s\n", col(k, cCyan), string(b))
		}
	}

	if p.Aborted != "" {
		fmt.Printf("  %s %s\n", col("aborted:", cMagenta), p.Aborted)
	}
	fmt.Println()
}

// ============================================================================
// 11. JSON 报告
// ============================================================================

// 包成 AgentHarness 想要的形态:扁平,含 deriveStatus 字段,便于程序化消费。
func printJSONReport(cfg cliConfig, result *AuditResult, parsed []*ScenarioPayload) {
	type sceneOut struct {
		ScenarioID string           `json:"scenarioId"`
		Status     string           `json:"status"`
		Intent     string           `json:"intent,omitempty"`
		Hypothesis string           `json:"hypothesis,omitempty"`
		Tags       []string         `json:"tags,omitempty"`
		DurationMs int64            `json:"durationMs"`
		InfraError string           `json:"infraError,omitempty"`
		Payload    *ScenarioPayload `json:"payload,omitempty"`
	}
	out := struct {
		URL        string     `json:"url"`
		GameIntent string     `json:"gameIntent"`
		DurationMs int64      `json:"durationMs"`
		Scenarios  []sceneOut `json:"scenarios"`
	}{
		URL:        cfg.URL,
		GameIntent: gameIntent,
		DurationMs: result.DurationMs,
		Scenarios:  make([]sceneOut, len(result.Results)),
	}
	for i, r := range result.Results {
		out.Scenarios[i] = sceneOut{
			ScenarioID: r.ScenarioID,
			Status:     deriveStatus(parsed[i], r.InfraError),
			Intent:     r.Intent,
			Hypothesis: r.Hypothesis,
			Tags:       r.Tags,
			DurationMs: r.DurationMs,
			InfraError: r.InfraError,
			Payload:    parsed[i],
		}
	}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(out)
}

// ============================================================================
// 12. 工具(颜色 / wrap / splitCsv)
// ============================================================================

const (
	cReset   = "\x1b[0m"
	cBold    = "\x1b[1m"
	cDim     = "\x1b[2m"
	cRed     = "\x1b[31m"
	cGreen   = "\x1b[32m"
	cYellow  = "\x1b[33m"
	cMagenta = "\x1b[35m"
	cCyan    = "\x1b[36m"
)

var useColor = true

func col(s, c string) string {
	if !useColor {
		return s
	}
	return c + s + cReset
}

func verdictColor(v string) string {
	switch strings.ToUpper(v) {
	case "PASS":
		return cGreen
	case "PARTIAL":
		return cYellow
	case "FAIL":
		return cRed
	case "INFRA_FAIL", "ABORTED":
		return cMagenta
	default:
		return cDim
	}
}

func splitCsv(s string) []string {
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func wrap(s string, width int) string {
	if width <= 0 || len(s) <= width {
		return s
	}
	var sb strings.Builder
	words := strings.Fields(s)
	line := 0
	for i, w := range words {
		if line+len(w)+1 > width && line > 0 {
			sb.WriteString("\n             ")
			line = 0
		}
		if i > 0 && line > 0 {
			sb.WriteString(" ")
			line++
		}
		sb.WriteString(w)
		line += len(w)
	}
	return sb.String()
}

func ifEmpty(s, fallback string) string {
	if s == "" {
		return fallback
	}
	return s
}
