import { useRef, useEffect, useCallback } from 'react';
import type { RefObject } from 'react';
import { create } from 'zustand';
import { withTelemetry } from './webops/runtime';

// ============================================================================
// 类型契约 — METHOD.md §5 / §9.1
// 这一组类型是组件之间唯一的接口源,所有 props 与 store 从这里派生
// ============================================================================

interface Lexeme {
  id: string;
  text: string;
  ipa: string;
  meaning: string;
  pos: string;
}

interface Bounds {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Zone {
  id: string;
  bounds: Bounds;
}

type ItemType = 'drag_scene_cloze' | 'drag_sentence_cloze';

type ErrorType = 'semantic' | 'position' | 'phonetic' | 'morphology' | 'unknown';

type FeedbackKind = 'correct' | 'position' | 'semantic' | 'unknown';

interface Feedback {
  kind: FeedbackKind;
  msg: string;
}

interface Attempt {
  itemId: string;
  answer: string;          // LexemeKey,但 attempt 是历史记录所以用宽松 string
  target: string;          // ZoneKey | 'sentence_blank'
  correct: boolean;
  latencyMs: number;
  hintUsed: boolean;
  errorType: ErrorType | null;
  timestamp: number;
}

interface ReviewItem {
  itemId: string;
  dueAt: number;
}

const PHASES = {
  IDLE: 'IDLE',
  CHOOSING: 'CHOOSING',
  HOVERING: 'HOVERING',
  CORRECT: 'CORRECT',
  INCORRECT: 'INCORRECT',
  COMPLETE: 'COMPLETE',
} as const;
type GamePhase = (typeof PHASES)[keyof typeof PHASES];

// ============================================================================
// 数据 — Lexeme / Zone / Item
// `satisfies` 校验形状但保留字面量,使 keyof 派生出 union
// ============================================================================

const LEXEMES = {
  coffee:   { id: 'lex_coffee',   text: 'coffee',   ipa: '/ˈkɒfi/',     meaning: '咖啡',     pos: 'n.' },
  beverage: { id: 'lex_beverage', text: 'beverage', ipa: '/ˈbɛvərɪdʒ/', meaning: '饮料',     pos: 'n.' },
  hot:      { id: 'lex_hot',      text: 'hot',      ipa: '/hɑt/',       meaning: '热的',     pos: 'adj.' },
  liquid:   { id: 'lex_liquid',   text: 'liquid',   ipa: '/ˈlɪkwɪd/',   meaning: '液体',     pos: 'n.' },
  cup:      { id: 'lex_cup',      text: 'cup',      ipa: '/kʌp/',       meaning: '杯子',     pos: 'n.' },
  saucer:   { id: 'lex_saucer',   text: 'saucer',   ipa: '/ˈsɔːsər/',   meaning: '茶托;浅碟', pos: 'n.' },
  cold:     { id: 'lex_cold',     text: 'cold',     ipa: '/koʊld/',     meaning: '冷的',     pos: 'adj.' },
  sweet:    { id: 'lex_sweet',    text: 'sweet',    ipa: '/swiːt/',     meaning: '甜的',     pos: 'adj.' },
  bitter:   { id: 'lex_bitter',   text: 'bitter',   ipa: '/ˈbɪtər/',    meaning: '苦的',     pos: 'adj.' },
} satisfies Record<string, Lexeme>;

type LexemeKey = keyof typeof LEXEMES;

const ZONES = {
  cup:    { id: 'zone_cup',    bounds: { x: 230, y: 165, w: 200, h: 130 } },
  saucer: { id: 'zone_saucer', bounds: { x: 175, y: 285, w: 290, h: 60  } },
  liquid: { id: 'zone_liquid', bounds: { x: 250, y: 165, w: 160, h: 35  } },
  hot:    { id: 'zone_hot',    bounds: { x: 260, y: 50,  w: 110, h: 110 } },
} satisfies Record<string, Zone>;

type ZoneKey = keyof typeof ZONES;
type DropTarget = ZoneKey | 'sentence_blank';

interface Item {
  id: string;
  type: ItemType;
  sentence: string;
  target: LexemeKey;
  targetZone?: ZoneKey;
  choices: LexemeKey[];
  hint: string;
  level: 1 | 2 | 3 | 4 | 5;
}

const ITEMS: Item[] = [
  {
    id: 'item_q1',
    type: 'drag_scene_cloze',
    sentence: 'The ____ is on the saucer.',
    target: 'cup',
    targetZone: 'cup',
    choices: ['cup', 'liquid', 'saucer', 'hot'],
    hint: '它装着咖啡,有一只把手。',
    level: 1,
  },
  {
    id: 'item_q2',
    type: 'drag_sentence_cloze',
    sentence: 'Coffee is a hot ____ .',
    target: 'beverage',
    choices: ['beverage', 'liquid', 'cup', 'saucer'],
    hint: '"饮料"的总称,比 liquid 更口语。',
    level: 1,
  },
  {
    id: 'item_q3',
    type: 'drag_scene_cloze',
    sentence: 'The ____ is under the cup.',
    target: 'saucer',
    targetZone: 'saucer',
    choices: ['saucer', 'cup', 'liquid', 'beverage'],
    hint: '杯子下面那只盘子。',
    level: 1,
  },
  {
    id: 'item_q4',
    type: 'drag_scene_cloze',
    sentence: 'The steam tells you the coffee is ____ .',
    target: 'hot',
    targetZone: 'hot',
    choices: ['hot', 'cold', 'sweet', 'bitter'],
    hint: '杯口冒出的白色气流就是答案的视觉证据。',
    level: 2,
  },
  {
    id: 'item_q5',
    type: 'drag_scene_cloze',
    sentence: 'The ____ in the cup is dark.',
    target: 'liquid',
    targetZone: 'liquid',
    choices: ['liquid', 'cup', 'saucer', 'beverage'],
    hint: '能流动的、看得见的物质。',
    level: 2,
  },
  {
    id: 'item_q6',
    type: 'drag_sentence_cloze',
    sentence: '____ is my favorite morning drink.',
    target: 'coffee',
    choices: ['coffee', 'cup', 'saucer', 'liquid'],
    hint: '这一关的主题词。',
    level: 2,
  },
];

// ============================================================================
// 状态机 — METHOD.md §6
// ============================================================================

interface GameState {
  phase: GamePhase;
  currentIdx: number;
  hintUsed: boolean;
  startedAt: number;
  draggedLex: LexemeKey | null;
  dragPointer: { x: number; y: number } | null;
  hoveredZone: DropTarget | null;
  filledBlank: LexemeKey | null;
  feedback: Feedback | null;
  attempts: Attempt[];
  reviewQueue: ReviewItem[];
  score: number;
}

type Action =
  | { type: 'START_DRAG'; lex: LexemeKey; pos: { x: number; y: number } }
  | { type: 'UPDATE_DRAG'; pos: { x: number; y: number }; zone: DropTarget | null }
  | { type: 'END_DRAG_MISS' }
  | { type: 'SUBMIT_SCENE'; lex: LexemeKey; zone: ZoneKey }
  | { type: 'SUBMIT_SENTENCE'; lex: LexemeKey }
  | { type: 'REQUEST_HINT' }
  | { type: 'NEXT' }
  | { type: 'RESTART' };

const initialState: GameState = {
  phase: PHASES.CHOOSING,
  currentIdx: 0,
  hintUsed: false,
  startedAt: Date.now(),
  draggedLex: null,
  dragPointer: null,
  hoveredZone: null,
  filledBlank: null,
  feedback: null,
  attempts: [],
  reviewQueue: [],
  score: 0,
};

function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'START_DRAG':
      return { ...state, phase: PHASES.CHOOSING, draggedLex: action.lex, dragPointer: action.pos };
    case 'UPDATE_DRAG':
      const zoneHovered = action.zone != null;
      const phaseChanged = zoneHovered !== (state.phase === PHASES.HOVERING);
      return {
        ...state,
        dragPointer: action.pos,
        hoveredZone: action.zone,
        ...(phaseChanged ? { phase: zoneHovered ? PHASES.HOVERING : PHASES.CHOOSING } : {}),
      };
    case 'END_DRAG_MISS':
      return { ...state, phase: PHASES.CHOOSING, draggedLex: null, dragPointer: null, hoveredZone: null };
    case 'SUBMIT_SCENE': {
      const item = ITEMS[state.currentIdx];
      const correct = action.zone === item.targetZone && action.lex === item.target;
      return submitAttempt(state, item, action.lex, action.zone, correct);
    }
    case 'SUBMIT_SENTENCE': {
      const item = ITEMS[state.currentIdx];
      const correct = action.lex === item.target;
      return submitAttempt(state, item, action.lex, 'sentence_blank', correct);
    }
    case 'REQUEST_HINT':
      return { ...state, hintUsed: true };
    case 'NEXT': {
      const nextIdx = state.currentIdx + 1;
      if (nextIdx >= ITEMS.length) return { ...state, phase: PHASES.COMPLETE };
      return {
        ...state,
        currentIdx: nextIdx,
        phase: PHASES.CHOOSING,
        hintUsed: false,
        startedAt: Date.now(),
        draggedLex: null,
        dragPointer: null,
        hoveredZone: null,
        filledBlank: null,
        feedback: null,
      };
    }
    case 'RESTART':
      return { ...initialState, startedAt: Date.now() };
  }
}

// ============================================================================
// Zustand store with dopharness telemetry
// ----------------------------------------------------------------------------
// 设计:reducer 保持纯函数不变。store 暴露一个 `dispatch(action)` 方法,
// 内部 `set(reducer(get(), action))` —— 把 V4 telemetry 装到不动 reducer 逻辑的前提下。
//
// 为什么不直接把 reducer 改成 N 个 action creator:reducer 是 METHOD.md §6 的核心,
// 集中状态机是它的特征,拆散就丢了。一次 set 触发一次 withTelemetry 的 diff 推送,
// 跟逐个 action creator 推送频次完全等价,但保留了"所有转移在一处"的可读性。
//
// 暴露给 dopharness 的 store 表面:
//   - 数值字段(score / currentIdx / attemptsCount / correctCount / latestLatencyMs)
//     被 VirtualChannel 自动采样,产出 K 线
//   - 枚举字段(phase / lastFeedbackKind / currentTarget / currentTargetZone)
//     通过 enums 映射成数字采样
//   - skip: ['attempts','reviewQueue','feedback','draggedLex','dragPointer','filledBlank','hoveredZone']
//     这些字段是大对象或瞬时态,不该进 K 线
//
// Script DSL 通过 `useGameStore.getState()` 读这些派生字段做断言。
// ============================================================================

interface GameStoreState extends GameState {
  // 派生:Script 用 read/expect 时直接拿
  attemptsCount: number;
  correctCount: number;
  latestLatencyMs: number;
  lastFeedbackKind: FeedbackKind | 'none';
  currentTarget: LexemeKey | 'none';
  currentTargetZone: ZoneKey | 'none';
  isCelebrationActive: boolean;       // 答对动画期间为 true,Script 用来等 celebration
  totalItems: number;
  // 命令式入口:复用 reducer
  dispatch: (action: Action) => void;
}

function deriveFields(state: GameState): Omit<GameStoreState, keyof GameState | 'dispatch'> {
  const item = ITEMS[state.currentIdx] as Item | undefined;
  const last = state.attempts[state.attempts.length - 1];
  return {
    attemptsCount: state.attempts.length,
    correctCount: state.attempts.filter((a) => a.correct).length,
    latestLatencyMs: last ? last.latencyMs : 0,
    lastFeedbackKind: state.feedback?.kind ?? 'none',
    currentTarget: item ? item.target : 'none',
    currentTargetZone: item?.targetZone ?? 'none',
    isCelebrationActive: state.phase === PHASES.CORRECT,
    totalItems: ITEMS.length,
  };
}

export const useGameStore = create<GameStoreState>()(
  withTelemetry<GameStoreState>({
    targetId: 'coffee_cloze_game',
    // 字符串枚举映射到数字,便于 K 线可视化
    enums: {
      phase: {
        IDLE: 0, CHOOSING: 1, HOVERING: 2, INCORRECT: -1, CORRECT: 2, COMPLETE: 3,
      },
      lastFeedbackKind: { none: 0, correct: 1, position: -1, semantic: -2, unknown: -3 },
      currentTarget:    { none: 0, coffee: 1, beverage: 2, hot: 3, liquid: 4, cup: 5, saucer: 6, cold: 7, sweet: 8, bitter: 9 },
      currentTargetZone:{ none: 0, hot: 1, cup: 2, liquid: 3, saucer: 4 },
    },
    // 非数值的复杂字段全部 skip
    skip: ['attempts', 'reviewQueue', 'feedback', 'draggedLex', 'dragPointer', 'filledBlank', 'hoveredZone', 'dispatch'],
  })((set, get) => ({
    ...initialState,
    ...deriveFields(initialState),
    dispatch: (action: Action) => {
      const next = reducer(get(), action);
      set({ ...next, ...deriveFields(next) });
    },
  })),
);

// 暴露到 window,供 Script DSL `useGameStore.getState()` 读取 —— dopharness 约定。
// 只在审计模式(?webops=1 或 dev)注入,避免污染生产 window。
if (typeof window !== 'undefined') {
  const w = window as unknown as { useGameStore?: typeof useGameStore };
  if (!w.useGameStore) w.useGameStore = useGameStore;
}

function submitAttempt(
  state: GameState,
  item: Item,
  lex: LexemeKey,
  zoneOrSlot: ZoneKey | 'sentence_blank',
  correct: boolean,
): GameState {
  const latencyMs = Date.now() - state.startedAt;
  const errorType: ErrorType | null = correct ? null : classifyError(item, lex, zoneOrSlot);
  const attempt: Attempt = {
    itemId: item.id,
    answer: lex,
    target: zoneOrSlot,
    correct,
    latencyMs,
    hintUsed: state.hintUsed,
    errorType,
    timestamp: Date.now(),
  };

  // 评分 — METHOD.md §7.2
  let score = state.score;
  if (correct) {
    const base = 100 * item.level;
    const hintPenalty = state.hintUsed ? 0.3 : 0;
    const latencyDecay =
      latencyMs < 3000 ? 0 :
      latencyMs < 6000 ? ((latencyMs - 3000) / 3000) * 0.3 :
      0.5;
    score += Math.round(base * (1 - hintPenalty) * (1 - latencyDecay));
  }

  // 复习队列 — METHOD.md §8: 错就 30s 后复现
  const reviewQueue: ReviewItem[] = correct
    ? state.reviewQueue
    : [...state.reviewQueue, { itemId: item.id, dueAt: Date.now() + 30_000 }];

  return {
    ...state,
    phase: correct ? PHASES.CORRECT : PHASES.INCORRECT,
    feedback: buildFeedback(item, lex, zoneOrSlot, correct),
    attempts: [...state.attempts, attempt],
    score,
    reviewQueue,
    draggedLex: null,
    dragPointer: null,
    hoveredZone: null,
    filledBlank: correct ? lex : null,
  };
}

function classifyError(item: Item, lex: LexemeKey, zoneOrSlot: ZoneKey | 'sentence_blank'): ErrorType {
  if (item.type === 'drag_scene_cloze') {
    if (lex === item.target && zoneOrSlot !== item.targetZone) return 'position';
    if (lex !== item.target) return 'semantic';
  } else {
    return 'semantic';
  }
  return 'unknown';
}

function buildFeedback(
  item: Item,
  lex: LexemeKey,
  zoneOrSlot: ZoneKey | 'sentence_blank',
  correct: boolean,
): Feedback {
  if (correct) return { kind: 'correct', msg: `✓ ${LEXEMES[lex].text} — ${LEXEMES[lex].meaning}` };
  const errType = classifyError(item, lex, zoneOrSlot);
  if (errType === 'position') return { kind: 'position', msg: `词对了,但位置不对 — ${LEXEMES[lex].text} 应该在另一处。` };
  if (errType === 'semantic') return { kind: 'semantic', msg: `语义不符 — ${LEXEMES[lex].text}(${LEXEMES[lex].meaning})不是正确答案。` };
  return { kind: 'unknown', msg: '再试一次。' };
}

// ============================================================================
// 拖拽工具 — 基于 SVG userSpaceOnUse 坐标 (METHOD.md §4.1)
// ============================================================================

interface SVGPoint2D { x: number; y: number; }

function screenToSVG(svgEl: SVGSVGElement | null, clientX: number, clientY: number): SVGPoint2D | null {
  if (!svgEl) return null;
  const pt = svgEl.createSVGPoint();
  pt.x = clientX;
  pt.y = clientY;
  const ctm = svgEl.getScreenCTM();
  if (!ctm) return null;
  const r = pt.matrixTransform(ctm.inverse());
  return { x: r.x, y: r.y };
}

/**
 * 按面积升序排列的 zone keys。
 *
 * 为什么:liquid 的 bounds 完全落在 cup 的 bounds 内部。如果按插入顺序遍历,
 * cup 永远先命中,liquid 永远拿不到拖放。按面积升序后,小 zone(liquid)优先,
 * 大 zone(cup)兜底。这等价于"嵌套盒子里点哪个,算最内层那个"的常识。
 */
const ZONE_KEYS_BY_AREA: readonly ZoneKey[] = (Object.keys(ZONES) as ZoneKey[]).sort(
  (a, b) => ZONES[a].bounds.w * ZONES[a].bounds.h - ZONES[b].bounds.w * ZONES[b].bounds.h,
);

function hitTestZone(svgPoint: SVGPoint2D): ZoneKey | null {
  for (const key of ZONE_KEYS_BY_AREA) {
    const b = ZONES[key].bounds;
    if (
      svgPoint.x >= b.x && svgPoint.x <= b.x + b.w &&
      svgPoint.y >= b.y && svgPoint.y <= b.y + b.h
    ) return key;
  }
  return null;
}

// ============================================================================
// Audio — METHOD.md §9.2 降级:用 Web Speech 作为 mp3 缺失时的 fallback
// ============================================================================

const speechQueue: { text: string; lang: string }[] = [];
let speechPlaying = false;

function speak(text: string, lang: string = 'en-US'): void {
  if (typeof window === 'undefined' || !window.speechSynthesis) return;
  speechQueue.push({ text, lang });
  if (!speechPlaying) processSpeechQueue();
}

function processSpeechQueue(): void {
  if (typeof window === 'undefined' || !window.speechSynthesis || speechQueue.length === 0) {
    speechPlaying = false;
    return;
  }
  speechPlaying = true;
  const { text, lang } = speechQueue.shift()!;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    u.rate = 0.95;
    u.onend = () => processSpeechQueue();
    u.onerror = () => processSpeechQueue();
    window.speechSynthesis.speak(u);
  } catch {
    /* 静默降级 */
    processSpeechQueue();
  }
}

// ============================================================================
// 主组件
// ============================================================================

export default function CoffeeClozeGame(): JSX.Element {
  // 用 zustand selectors 订阅 — 整 state + dispatch 都从 store 取。
  // 单 selector 返回整对象时,zustand 会浅比较;由于 dispatch 用 set(...next),
  // state 引用必变,每次 dispatch 触发一次 rerender,与原 useReducer 行为一致。
  const state = useGameStore();
  const dispatch = state.dispatch;
  const svgRef = useRef<SVGSVGElement | null>(null);
  const sentenceBlankRef = useRef<HTMLSpanElement | null>(null);
  const dragLexRef = useRef<LexemeKey | null>(null);

  const item = ITEMS[state.currentIdx];
  const isSceneType = item?.type === 'drag_scene_cloze';

  // ---------- 拖拽事件 ----------
  //
  // 核心修复: onPointerMove / onPointerUp 用 useCallback 稳定闭包,
  // 避免 useEffect 无依赖数组导致的"每次渲染都拆换 window listener"问题。
  // 之前: useEffect 无 deps → 每次 START_DRAG / UPDATE_DRAG dispatch 后
  //   re-render → cleanup 移除旧 handler → 添加新 handler → 拖放链断裂。
  //
  const onPointerDown = useCallback((e: React.PointerEvent<HTMLButtonElement>, lexKey: LexemeKey): void => {
    e.preventDefault();
    dragLexRef.current = lexKey;
    dispatch({ type: 'START_DRAG', lex: lexKey, pos: { x: e.clientX, y: e.clientY } });
    e.currentTarget.setPointerCapture(e.pointerId);
  }, [dispatch]);

  const onPointerMove = useCallback((e: PointerEvent): void => {
    if (!dragLexRef.current) return;
    let hovered: DropTarget | null = null;
    if (isSceneType && svgRef.current) {
      const svgRect = svgRef.current.getBoundingClientRect();
      if (e.clientX >= svgRect.left - 50 && e.clientX <= svgRect.right + 50 &&
          e.clientY >= svgRect.top - 50 && e.clientY <= svgRect.bottom + 50) {
        const p = screenToSVG(svgRef.current, e.clientX, e.clientY);
        if (p) hovered = hitTestZone(p);
      }
    } else if (!isSceneType && sentenceBlankRef.current) {
      const r = sentenceBlankRef.current.getBoundingClientRect();
      const pad = 12;
      if (
        e.clientX >= r.left - pad && e.clientX <= r.right + pad &&
        e.clientY >= r.top - pad && e.clientY <= r.bottom + pad
      ) hovered = 'sentence_blank';
    }
    dispatch({ type: 'UPDATE_DRAG', pos: { x: e.clientX, y: e.clientY }, zone: hovered });
  }, [isSceneType, dispatch]);

  const onPointerUp = useCallback((e: PointerEvent): void => {
    const lex = dragLexRef.current;
    if (!lex) return;
    dragLexRef.current = null;

    let zone: DropTarget | null = null;
    if (isSceneType && svgRef.current) {
      const p = screenToSVG(svgRef.current, e.clientX, e.clientY);
      if (p) zone = hitTestZone(p);
    } else if (!isSceneType && sentenceBlankRef.current) {
      const r = sentenceBlankRef.current.getBoundingClientRect();
      const pad = 12;
      if (
        e.clientX >= r.left - pad && e.clientX <= r.right + pad &&
        e.clientY >= r.top - pad && e.clientY <= r.bottom + pad
      ) zone = 'sentence_blank';
    }

    if (zone === 'sentence_blank') {
      dispatch({ type: 'SUBMIT_SENTENCE', lex });
      speak(LEXEMES[lex].text);
    } else if (zone) {
      dispatch({ type: 'SUBMIT_SCENE', lex, zone });
      speak(LEXEMES[lex].text);
    } else {
      dispatch({ type: 'END_DRAG_MISS' });
    }
  }, [isSceneType, dispatch]);

  useEffect(() => {
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    return () => {
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
    };
  }, [onPointerMove, onPointerUp]);

  // ---------- 听句:正确后播 sentence audio ----------
  useEffect(() => {
    if (state.phase === PHASES.CORRECT && item) {
      const fullSentence = item.sentence.replace('____', LEXEMES[item.target].text);
      const t = setTimeout(() => speak(fullSentence), 600);
      return () => clearTimeout(t);
    }
  }, [state.phase, state.currentIdx, item]);

  // ---------- 句子里把 ____ 渲染为 drop slot ----------
  const renderSentenceWithBlank = (): JSX.Element | null => {
    if (!item) return null;
    const parts = item.sentence.split('____');
    const filled = state.filledBlank;
    const isHover = state.hoveredZone === 'sentence_blank';
    return (
      <span className="leading-loose">
        {parts[0]}
        <span
          ref={sentenceBlankRef}
          data-vt-id="sentence-blank"
          data-zone-id="sentence_blank"
          className={[
            'inline-block min-w-[120px] px-3 py-1 mx-1 rounded border-b-2 align-middle text-center transition-colors',
            filled
              ? 'border-emerald-700 bg-emerald-50 text-emerald-900'
              : isHover
              ? 'border-amber-600 bg-amber-100/60 border-dashed'
              : 'border-stone-600 border-dashed text-stone-400',
          ].join(' ')}
        >
          {filled ? LEXEMES[filled].text : '\u00A0'}
        </span>
        {parts[1]}
      </span>
    );
  };

  if (state.phase === PHASES.COMPLETE) {
    return <CompleteScreen state={state} onRestart={() => dispatch({ type: 'RESTART' })} />;
  }

  return (
    <div
      data-vt-id="game-root"
      className="min-h-screen w-full p-4 md:p-8 bg-gradient-to-b from-stone-100 via-stone-200/70 to-stone-300/60"
      style={{ fontFamily: '"Cormorant Garamond", "Source Han Serif SC", Georgia, serif' }}
    >
      <div className="max-w-6xl mx-auto">
        <Header state={state} totalItems={ITEMS.length} />

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 mt-6">
          <div className="lg:col-span-3">
            <SceneCard
              svgRef={svgRef}
              hoveredZone={isSceneType ? (state.hoveredZone as ZoneKey | null) : null}
              correctTargetZone={state.phase === PHASES.CORRECT ? item.targetZone ?? null : null}
              isSceneType={isSceneType}
            />
          </div>

          <div className="lg:col-span-2 flex flex-col gap-4">
            <QuestionCard
              item={item}
              isSceneType={isSceneType}
              renderSentence={renderSentenceWithBlank}
              onPlayAudio={() => speak(item.sentence.replace('____', LEXEMES[item.target].text))}
              hintUsed={state.hintUsed}
              onRequestHint={() => dispatch({ type: 'REQUEST_HINT' })}
            />

            <WordTray
              item={item}
              draggedLex={state.draggedLex}
              filledBlank={state.filledBlank}
              phase={state.phase}
              onPointerDown={onPointerDown}
            />

            <FeedbackPanel
              feedback={state.feedback}
              phase={state.phase}
              onNext={() => dispatch({ type: 'NEXT' })}
            />
          </div>
        </div>

        {state.draggedLex && state.dragPointer && (
          <DragGhost lex={state.draggedLex} pointer={state.dragPointer} />
        )}

        <ReviewQueueBar reviewQueue={state.reviewQueue} attempts={state.attempts} />
      </div>
    </div>
  );
}

// ============================================================================
// Header
// ============================================================================

interface HeaderProps {
  state: GameState;
  totalItems: number;
}

function Header({ state, totalItems }: HeaderProps): JSX.Element {
  const progress = ((state.currentIdx + 1) / totalItems) * 100;
  return (
    <header data-vt-id="game-header" className="flex flex-col gap-3">
      <div className="flex items-end justify-between flex-wrap gap-2">
        <div>
          <div className="text-xs tracking-[0.3em] text-stone-500 uppercase mb-1">Scene 01</div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-emerald-900">
            coffee<span className="text-amber-700">.</span>
          </h1>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs text-stone-500 uppercase tracking-wider">Score</span>
            <span data-vt-id="score-display" className="text-2xl font-bold text-emerald-800 font-mono tabular-nums">
              {state.score}
            </span>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs text-stone-500 uppercase tracking-wider">Item</span>
            <span className="text-2xl font-bold text-stone-700 font-mono tabular-nums">
              {state.currentIdx + 1}
              <span className="text-stone-400">/{totalItems}</span>
            </span>
          </div>
        </div>
      </div>
      <div className="w-full h-1 bg-stone-300/50 rounded-full overflow-hidden">
        <div
          data-vt-id="progress-bar"
          className="h-full bg-gradient-to-r from-emerald-700 to-emerald-500 transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
    </header>
  );
}

// ============================================================================
// SVG 子组件群 — 每个 zone 是独立顶层函数,AST 友好
// ----------------------------------------------------------------------------
// 命名约定:
//   - *Zone (交互热区) / *Label (纯文本标注) / *Pattern (背景)
//   - 全部 zone 组件统一签名 ZoneCmpProps
// ============================================================================

interface ZoneCmpProps {
  hoveredZone: ZoneKey | null;
  correctTargetZone: ZoneKey | null;
  isSceneType: boolean;
}

/** zone hitArea 的 hover 描边 — 仅 CHOOSING/HOVERING 阶段使用。
 *  注意:correct 状态不在这里处理,而是由独立的 CelebrationBg/Fg 层覆盖,
 *  原因是"答对庆祝"是多层视觉(背景+边框+星标+标签强化),无法用单一 className 表达。 */
function zoneClassName(
  zoneKey: ZoneKey,
  hoveredZone: ZoneKey | null,
  isSceneType: boolean,
): string {
  if (hoveredZone === zoneKey && isSceneType) return 'stroke-amber-600 fill-amber-200/30';
  return 'stroke-transparent fill-transparent';
}

/** 教科书纸的网格底纹。 */
function GridPattern(): JSX.Element {
  return (
    <>
      <defs>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#d4c89a" strokeWidth="0.5" opacity="0.3" />
        </pattern>
      </defs>
      <rect data-vt-id="scene-bg-grid" width="600" height="400" fill="url(#grid)" />
    </>
  );
}

// ----------------------------------------------------------------------------
// 答对后的"注意力标记"四件套
// ----------------------------------------------------------------------------
// 1) 荧光笔斜纹背景 — 学生用 highlighter 标重点的视觉
// 2) 金色脉冲边框 — 持续吸引视线
// 3) ★ 徽章 — 老师在试卷上画的小星星
// 4) 标签字体强化 — emerald-900 改 amber-700,字号+4,fontWeight 900
//
// 1/2 是 CelebrationBg(z 序在线稿下方,所以杯子轮廓压在荧光笔上,像真实荧光笔效果)
// 3   是 CelebrationFg(z 序最顶,徽章一定在最上)
// 4   是 ZoneLabel 内的 isCorrect 分支
// ----------------------------------------------------------------------------

/** 庆祝用的 SVG defs:荧光笔 pattern + 金色光晕 filter。仅渲染一次。 */
function CelebrationDefs(): JSX.Element {
  return (
    <defs>
      {/* 荧光笔斜纹 pattern — 倾斜 15°,模拟手画笔触 */}
      <pattern
        id="highlighter-pattern"
        width="8" height="8"
        patternUnits="userSpaceOnUse"
        patternTransform="rotate(-15)"
      >
        <rect width="8" height="8" fill="#fef08a" />
        <line x1="0" y1="2" x2="8" y2="2" stroke="#fde047" strokeWidth="0.6" opacity="0.6" />
        <line x1="0" y1="6" x2="8" y2="6" stroke="#facc15" strokeWidth="0.4" opacity="0.4" />
      </pattern>
      {/* 金色光晕滤镜 — 用于脉冲边框 */}
      <filter id="celebrate-glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="2.5" result="blur" />
        <feMerge>
          <feMergeNode in="blur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>
  );
}

/** 庆祝层背景:荧光笔填充 + 脉冲边框。
 *  放在 zone group 最前,这样线稿压在它上面 — 像真荧光笔标重点。 */
function CelebrationBg({ zoneKey }: { zoneKey: ZoneKey }): JSX.Element {
  const b = ZONES[zoneKey].bounds;
  const pad = 6; // 略微外扩,让标记包裹住边缘
  return (
    <g data-vt-id={`celebration-bg-${zoneKey}`} pointerEvents="none">
      {/* 荧光笔填充 — 0.4s 内淡入到 0.7 opacity */}
      <rect
        x={b.x - pad} y={b.y - pad}
        width={b.w + pad * 2} height={b.h + pad * 2}
        rx="6"
        fill="url(#highlighter-pattern)"
        opacity="0"
      >
        <animate attributeName="opacity" from="0" to="0.7" dur="0.4s" fill="freeze" />
      </rect>
      {/* 金色脉冲边框 — 不断呼吸 */}
      <rect
        x={b.x - pad} y={b.y - pad}
        width={b.w + pad * 2} height={b.h + pad * 2}
        rx="6"
        fill="none"
        stroke="#d97706"
        strokeWidth="3"
        opacity="0.85"
        filter="url(#celebrate-glow)"
      >
        <animate
          attributeName="opacity"
          values="0.4;1;0.4"
          dur="1.6s"
          repeatCount="indefinite"
        />
        <animate
          attributeName="stroke-width"
          values="2.5;4.5;2.5"
          dur="1.6s"
          repeatCount="indefinite"
        />
      </rect>
    </g>
  );
}

/** 庆祝层前景:★ 徽章。z 序最顶,确保压在所有线稿与标签上。 */
function CelebrationFg({ zoneKey }: { zoneKey: ZoneKey }): JSX.Element {
  const b = ZONES[zoneKey].bounds;
  // 徽章定位在 zone 右上角外侧
  const cx = b.x + b.w - 2;
  const cy = b.y - 2;
  return (
    <g data-vt-id={`celebration-fg-${zoneKey}`} pointerEvents="none" opacity="0">
      <animate attributeName="opacity" from="0" to="1" dur="0.5s" begin="0.3s" fill="freeze" />
      <circle cx={cx} cy={cy} r="14" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
      <text
        x={cx}
        y={cy + 1}
        fontFamily="Cormorant Garamond, Georgia, serif"
        fontSize="20"
        fontWeight="900"
        fill="#b45309"
        textAnchor="middle"
        dominantBaseline="central"
      >
        ★
      </text>
    </g>
  );
}

/** ZONE: hot — 杯口三股热气 + 透明 hitArea。 */
function HotZone({ hoveredZone, correctTargetZone, isSceneType }: ZoneCmpProps): JSX.Element {
  const isCorrect = correctTargetZone === 'hot';
  return (
    <g data-vt-id="zone-hot" data-zone-id="hot" data-bounds="260,50,110,110" data-vt-watch="opacity">
      {isCorrect && <CelebrationBg zoneKey="hot" />}
      <path d="M 290 150 Q 280 130 295 110 Q 308 90 290 65"
            fill="none" stroke="#2f6e3a" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 315 150 Q 305 125 320 100 Q 333 75 318 55"
            fill="none" stroke="#2f6e3a" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 340 150 Q 330 130 345 110 Q 358 90 340 65"
            fill="none" stroke="#2f6e3a" strokeWidth="2.5" strokeLinecap="round" />
      <rect
        data-vt-id="zone-hot-hitarea"
        x="260" y="50" width="110" height="110"
        fill="transparent" pointerEvents="all"
        className={zoneClassName('hot', hoveredZone, isSceneType)}
        strokeWidth="2" strokeDasharray="4,3"
      />
      <ZoneLabel x={385} y={100} label="hot" ipa="/hɑt/" meaning="热的" pos="adj." anchor="left" isCorrect={isCorrect} />
      {isCorrect && <CelebrationFg zoneKey="hot" />}
    </g>
  );
}

/** ZONE: cup — 梯形杯身 + 杯口椭圆 + 把手 + hitArea。 */
function CupZone({ hoveredZone, correctTargetZone, isSceneType }: ZoneCmpProps): JSX.Element {
  const isCorrect = correctTargetZone === 'cup';
  return (
    <g data-vt-id="zone-cup" data-zone-id="cup" data-bounds="230,165,200,130" data-vt-watch="opacity,transform">
      {isCorrect && <CelebrationBg zoneKey="cup" />}
      <path
        d="M 250 175 L 270 285 Q 330 295 390 285 L 410 175"
        fill="#fdfaf2" stroke="#2f6e3a" strokeWidth="3" strokeLinejoin="round"
      />
      <ellipse cx="330" cy="175" rx="80" ry="9" fill="#fdfaf2" stroke="#2f6e3a" strokeWidth="3" />
      <path
        d="M 410 195 Q 445 200 445 230 Q 445 260 405 265"
        fill="none" stroke="#2f6e3a" strokeWidth="3" strokeLinecap="round"
      />
      <rect
        data-vt-id="zone-cup-hitarea"
        x="230" y="165" width="200" height="130"
        fill="transparent" pointerEvents="all"
        className={zoneClassName('cup', hoveredZone, isSceneType)}
        strokeWidth="2" strokeDasharray="4,3"
      />
      <ZoneLabel x={155} y={235} label="cup" ipa="/kʌp/" meaning="杯子" pos="n." anchor="right" isCorrect={isCorrect} />
      {isCorrect && <CelebrationFg zoneKey="cup" />}
    </g>
  );
}

/** ZONE: liquid — 杯口处暗色液面 + hitArea。 */
function LiquidZone({ hoveredZone, correctTargetZone, isSceneType }: ZoneCmpProps): JSX.Element {
  const isCorrect = correctTargetZone === 'liquid';
  return (
    <g data-vt-id="zone-liquid" data-zone-id="liquid" data-bounds="250,165,160,35" data-vt-watch="opacity">
      {isCorrect && <CelebrationBg zoneKey="liquid" />}
      <ellipse cx="330" cy="178" rx="76" ry="6" fill="#3a2818" stroke="#2f6e3a" strokeWidth="1.5" opacity="0.85" />
      <ellipse cx="330" cy="176" rx="68" ry="3" fill="#5c3a1f" opacity="0.6" />
      <rect
        data-vt-id="zone-liquid-hitarea"
        x="250" y="165" width="160" height="35"
        fill="transparent" pointerEvents="all"
        className={zoneClassName('liquid', hoveredZone, isSceneType)}
        strokeWidth="2" strokeDasharray="4,3"
      />
      <ZoneLabel x={480} y={170} label="liquid" ipa="/ˈlɪkwɪd/" meaning="液体" pos="n." anchor="left" isCorrect={isCorrect} />
      {isCorrect && <CelebrationFg zoneKey="liquid" />}
    </g>
  );
}

/** ZONE: saucer — 双层椭圆茶托 + hitArea。 */
function SaucerZone({ hoveredZone, correctTargetZone, isSceneType }: ZoneCmpProps): JSX.Element {
  const isCorrect = correctTargetZone === 'saucer';
  return (
    <g data-vt-id="zone-saucer" data-zone-id="saucer" data-bounds="175,285,290,60" data-vt-watch="opacity">
      {isCorrect && <CelebrationBg zoneKey="saucer" />}
      <ellipse cx="330" cy="310" rx="140" ry="14" fill="#fdfaf2" stroke="#2f6e3a" strokeWidth="3" />
      <ellipse cx="330" cy="305" rx="115" ry="9" fill="none" stroke="#2f6e3a" strokeWidth="1.8" opacity="0.7" />
      <rect
        data-vt-id="zone-saucer-hitarea"
        x="175" y="285" width="290" height="60"
        fill="transparent" pointerEvents="all"
        className={zoneClassName('saucer', hoveredZone, isSceneType)}
        strokeWidth="2" strokeDasharray="4,3"
      />
      <ZoneLabel x={155} y={325} label="saucer" ipa="/ˈsɔːsər/" meaning="茶托" pos="n." anchor="right" isCorrect={isCorrect} />
      {isCorrect && <CelebrationFg zoneKey="saucer" />}
    </g>
  );
}

/** "beverage" 是 cup + liquid 的概念组合,没有专属视觉,只有文字注解。 */
function BeverageLabel(): JSX.Element {
  return (
    <g data-vt-id="zone-beverage-conceptual" opacity="0.6">
      <text x="40" y="60" fontFamily="ui-monospace, monospace" fontSize="11" fill="#7a6a4a" letterSpacing="0.15em">
        beverage = cup + liquid
      </text>
    </g>
  );
}

/**
 * SceneSvg — 纯组合层。
 * 顺序即层级,GridPattern 最底,HotZone 最上。
 */
interface SceneSvgProps extends ZoneCmpProps {
  svgRef: RefObject<SVGSVGElement | null>;
}

function SceneSvg({ svgRef, hoveredZone, correctTargetZone, isSceneType }: SceneSvgProps): JSX.Element {
  const zoneProps: ZoneCmpProps = { hoveredZone, correctTargetZone, isSceneType };
  return (
    <svg
      ref={svgRef}
      data-vt-id="coffee-scene-svg"
      viewBox="0 0 600 400"
      className="w-full h-auto mt-8"
      style={{ touchAction: 'none' }}
    >
      <GridPattern />
      <CelebrationDefs />
      <HotZone {...zoneProps} />
      <CupZone {...zoneProps} />
      <LiquidZone {...zoneProps} />
      <SaucerZone {...zoneProps} />
      <BeverageLabel />
    </svg>
  );
}

interface SceneCardProps extends ZoneCmpProps {
  svgRef: RefObject<SVGSVGElement | null>;
}

function SceneCard({ svgRef, hoveredZone, correctTargetZone, isSceneType }: SceneCardProps): JSX.Element {
  return (
    <div
      data-vt-id="scene-card"
      className="relative rounded-lg p-6 shadow-md bg-gradient-to-br from-stone-50 to-amber-50/40 ring-1 ring-stone-300/50"
      style={{ touchAction: 'none' }}
    >
      <div className="absolute top-3 left-3 px-3 py-1 bg-emerald-800 text-amber-50 text-xs tracking-[0.2em] uppercase font-mono">
        coffee
      </div>
      <div className="absolute top-3 right-3 text-xs text-stone-400 font-mono">
        viewBox: 0 0 600 400
      </div>
      <SceneSvg
        svgRef={svgRef}
        hoveredZone={hoveredZone}
        correctTargetZone={correctTargetZone}
        isSceneType={isSceneType}
      />
    </div>
  );
}

interface ZoneLabelProps {
  x: number;
  y: number;
  label: string;
  ipa: string;
  meaning: string;
  pos: string;
  anchor: 'left' | 'right';
  isCorrect?: boolean;
}

function ZoneLabel({
  x, y, label, ipa, meaning, pos, anchor, isCorrect = false,
}: ZoneLabelProps): JSX.Element {
  const textAnchor: 'start' | 'end' = anchor === 'right' ? 'end' : 'start';
  // 答对时:字号 18→22,字重 700→900,颜色 emerald-900 → amber-700
  const mainFill = isCorrect ? '#b45309' : '#1d4a2a';
  const mainSize = isCorrect ? 22 : 18;
  const mainWeight = isCorrect ? 900 : 700;
  const ipaFill = isCorrect ? '#92400e' : '#7a6a4a';
  const subFill = isCorrect ? '#92400e' : '#5a5040';
  return (
    <g data-vt-id={`label-${label}`} pointerEvents="none">
      <text
        x={x} y={y}
        fontFamily="Cormorant Garamond, Georgia, serif"
        fontSize={mainSize}
        fontWeight={mainWeight}
        fill={mainFill}
        textAnchor={textAnchor}
        style={{ transition: 'fill 0.3s ease' }}
      >
        {label}
        <tspan fontFamily="ui-monospace, monospace" fontSize="11" fontWeight="400" fill={ipaFill} dx="6">
          {' '}{ipa}
        </tspan>
      </text>
      <text
        x={x} y={y + 16}
        fontFamily="Cormorant Garamond, Georgia, serif"
        fontSize="13"
        fill={subFill}
        fontStyle="italic"
        textAnchor={textAnchor}
      >
        {pos} {meaning}
      </text>
    </g>
  );
}

// ============================================================================
// QuestionCard
// ============================================================================

interface QuestionCardProps {
  item: Item;
  isSceneType: boolean;
  renderSentence: () => JSX.Element | null;
  onPlayAudio: () => void;
  hintUsed: boolean;
  onRequestHint: () => void;
}

function QuestionCard({
  item, isSceneType, renderSentence, onPlayAudio, hintUsed, onRequestHint,
}: QuestionCardProps): JSX.Element | null {
  if (!item) return null;
  return (
    <div
      data-vt-id="question-card"
      className="rounded-lg p-5 bg-stone-50 ring-1 ring-stone-300/50 shadow-sm"
    >
      <div className="flex items-center justify-between mb-3">
        <span className="text-[10px] tracking-[0.2em] uppercase text-stone-500 font-mono">
          {isSceneType ? '→ 拖词卡到图中正确部位' : '→ 拖词卡到句子空格'}
        </span>
        <button
          data-vt-id="audio-button"
          onClick={onPlayAudio}
          className="text-stone-500 hover:text-emerald-700 transition-colors"
          aria-label="播放例句"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
          </svg>
        </button>
      </div>
      <p data-vt-id="sentence-prompt" className="text-2xl text-stone-800 font-medium">
        {renderSentence()}
      </p>
      <div className="mt-4 flex items-center justify-between">
        <button
          data-vt-id="hint-button"
          onClick={onRequestHint}
          disabled={hintUsed}
          className="text-xs text-stone-500 hover:text-amber-700 disabled:opacity-50 underline-offset-2 hover:underline"
        >
          {hintUsed ? `提示: ${item.hint}` : '需要提示? (扣 30% 分)'}
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// WordTray
// ============================================================================

interface WordTrayProps {
  item: Item;
  draggedLex: LexemeKey | null;
  filledBlank: LexemeKey | null;
  phase: GamePhase;
  onPointerDown: (e: React.PointerEvent<HTMLButtonElement>, lexKey: LexemeKey) => void;
}

function WordTray({
  item, draggedLex, filledBlank, phase, onPointerDown,
}: WordTrayProps): JSX.Element | null {
  if (!item) return null;
  const disabled = phase === PHASES.CORRECT || phase === PHASES.INCORRECT;
  return (
    <div
      data-vt-id="word-tray"
      className="rounded-lg p-4 bg-stone-50 ring-1 ring-stone-300/50 shadow-sm"
    >
      <div className="text-[10px] tracking-[0.2em] uppercase text-stone-500 font-mono mb-3">
        word cards
      </div>
      <div className="flex flex-wrap gap-2">
        {item.choices.map((lexKey) => {
          const lex = LEXEMES[lexKey];
          const isUsed = filledBlank === lexKey;
          const isDragging = draggedLex === lexKey;
          return (
            <button
              key={lexKey}
              data-vt-id={`word-card-${lexKey}`}
              data-vt-watch="opacity,transform"
              onPointerDown={(e) => !disabled && !isUsed && onPointerDown(e, lexKey)}
              disabled={disabled || isUsed}
              className={[
                'group relative px-4 py-2 rounded select-none transition-all',
                'border-2 border-emerald-900',
                'font-mono text-sm font-bold',
                isUsed
                  ? 'opacity-30 cursor-not-allowed bg-stone-100 border-stone-400'
                  : disabled
                  ? 'opacity-50 cursor-not-allowed'
                  : 'bg-amber-50 hover:bg-amber-100 cursor-grab active:cursor-grabbing hover:-translate-y-0.5 hover:shadow-md',
                isDragging ? 'opacity-30' : '',
              ].join(' ')}
              style={{ touchAction: 'none' }}
            >
              <span className="text-emerald-900">{lex.text}</span>
              {lex.ipa && <span className="ml-1.5 text-[10px] font-normal text-stone-500">{lex.ipa}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================================
// FeedbackPanel
// ============================================================================

interface FeedbackPanelProps {
  feedback: Feedback | null;
  phase: GamePhase;
  onNext: () => void;
}

const FEEDBACK_STYLES: Record<FeedbackKind, { container: string; accent: string; label: string }> = {
  correct:  { container: 'bg-emerald-50 border-l-4 border-emerald-700 text-emerald-900', accent: 'bg-emerald-700',  label: 'correct' },
  position: { container: 'bg-amber-50 border-l-4 border-amber-700 text-amber-900',       accent: 'bg-amber-700',    label: 'position error' },
  semantic: { container: 'bg-rose-50 border-l-4 border-rose-700 text-rose-900',          accent: 'bg-rose-700',     label: 'semantic error' },
  unknown:  { container: 'bg-rose-50 border-l-4 border-rose-700 text-rose-900',          accent: 'bg-rose-700',     label: 'error' },
};

function FeedbackPanel({ feedback, phase, onNext }: FeedbackPanelProps): JSX.Element {
  if (!feedback) {
    return (
      <div
        data-vt-id="feedback-panel-idle"
        className="rounded-lg p-4 text-center text-xs text-stone-400 font-mono tracking-wider uppercase border-2 border-dashed border-stone-300"
      >
        waiting for your answer …
      </div>
    );
  }
  const style = FEEDBACK_STYLES[feedback.kind];
  return (
    <div
      data-vt-id={`feedback-panel-${feedback.kind}`}
      className={`rounded-lg p-4 flex items-center justify-between gap-3 ${style.container}`}
    >
      <div className="flex-1">
        <div className="text-[10px] tracking-[0.2em] uppercase font-mono opacity-70">
          {style.label}
        </div>
        <div className="text-base font-medium mt-0.5">{feedback.msg}</div>
      </div>
      <button
        data-vt-id="next-button"
        onClick={onNext}
        className={`px-4 py-2 rounded font-mono text-xs tracking-wider uppercase font-bold text-amber-50 hover:opacity-90 transition-opacity ${style.accent}`}
      >
        {phase === PHASES.CORRECT ? 'next →' : 'try next →'}
      </button>
    </div>
  );
}

// ============================================================================
// DragGhost
// ============================================================================

interface DragGhostProps {
  lex: LexemeKey;
  pointer: { x: number; y: number };
}

function DragGhost({ lex, pointer }: DragGhostProps): JSX.Element {
  const lexObj = LEXEMES[lex];
  return (
    <div
      data-vt-id="drag-ghost"
      className="fixed pointer-events-none z-50 px-4 py-2 rounded border-2 border-emerald-900 bg-amber-50 font-mono text-sm font-bold shadow-2xl"
      style={{
        position: 'fixed',
        left: 0,
        top: 0,
        transform: `translate(${pointer.x}px, ${pointer.y}px) translate(-50%, -120%) rotate(-3deg)`,
        willChange: 'transform',
      }}
    >
      <span className="text-emerald-900">{lexObj.text}</span>
      <span className="ml-1.5 text-[10px] font-normal text-stone-500">{lexObj.ipa}</span>
    </div>
  );
}

// ============================================================================
// ReviewQueueBar
// ============================================================================

interface ReviewQueueBarProps {
  reviewQueue: ReviewItem[];
  attempts: Attempt[];
}

function ReviewQueueBar({ reviewQueue, attempts }: ReviewQueueBarProps): JSX.Element {
  const correctRate = attempts.length === 0
    ? '—'
    : `${Math.round((attempts.filter((a) => a.correct).length / attempts.length) * 100)}%`;
  const avgLatency = attempts.length === 0
    ? '—'
    : `${Math.round(attempts.reduce((s, a) => s + a.latencyMs, 0) / attempts.length)}ms`;
  return (
    <div data-vt-id="review-queue-bar" className="mt-8 text-[10px] font-mono text-stone-500 flex items-center gap-4 flex-wrap">
      <span className="tracking-[0.2em] uppercase">debug:</span>
      <span data-vt-id="attempts-count">attempts={attempts.length}</span>
      <span data-vt-id="review-queue-size">review_queue={reviewQueue.length}</span>
      <span data-vt-id="correct-rate">correct_rate={correctRate}</span>
      <span data-vt-id="avg-latency">avg_latency={avgLatency}</span>
    </div>
  );
}

// ============================================================================
// CompleteScreen
// ============================================================================

interface CompleteScreenProps {
  state: GameState;
  onRestart: () => void;
}

function CompleteScreen({ state, onRestart }: CompleteScreenProps): JSX.Element {
  const total = state.attempts.length;
  const correct = state.attempts.filter((a) => a.correct).length;
  const accuracy = total === 0 ? 0 : Math.round((correct / total) * 100);
  const avgLatency = total === 0 ? 0 : Math.round(state.attempts.reduce((s, a) => s + a.latencyMs, 0) / total);
  return (
    <div
      data-vt-id="complete-screen"
      className="min-h-screen flex items-center justify-center p-8 bg-gradient-to-b from-stone-100 via-stone-200/70 to-stone-300/60"
      style={{ fontFamily: '"Cormorant Garamond", "Source Han Serif SC", Georgia, serif' }}
    >
      <div className="max-w-md w-full rounded-lg p-8 text-center bg-stone-50 ring-1 ring-stone-300/50 shadow-xl">
        <div className="text-xs tracking-[0.3em] uppercase text-stone-500 mb-3">Scene Complete</div>
        <h2 className="text-5xl font-bold text-emerald-900 mb-1">{state.score}</h2>
        <div className="text-xs text-stone-500 uppercase tracking-wider mb-8">total score</div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div data-vt-id="stat-accuracy">
            <div className="text-2xl font-bold font-mono text-emerald-800">{accuracy}%</div>
            <div className="text-[10px] uppercase tracking-wider text-stone-500 mt-1">accuracy</div>
          </div>
          <div data-vt-id="stat-correct">
            <div className="text-2xl font-bold font-mono text-emerald-800">{correct}/{total}</div>
            <div className="text-[10px] uppercase tracking-wider text-stone-500 mt-1">correct</div>
          </div>
          <div data-vt-id="stat-latency">
            <div className="text-2xl font-bold font-mono text-emerald-800">
              {avgLatency}<span className="text-sm">ms</span>
            </div>
            <div className="text-[10px] uppercase tracking-wider text-stone-500 mt-1">avg latency</div>
          </div>
        </div>

        {state.reviewQueue.length > 0 && (
          <div className="mt-6 px-4 py-2 bg-amber-50 border-l-2 border-amber-600 text-left">
            <div className="text-[10px] tracking-[0.2em] uppercase text-amber-800 font-mono">spaced review</div>
            <div className="text-sm text-amber-900 mt-0.5">
              {state.reviewQueue.length} item(s) scheduled for 30s recurrence
            </div>
          </div>
        )}

        <button
          data-vt-id="restart-button"
          onClick={onRestart}
          className="mt-8 px-6 py-3 bg-emerald-800 hover:bg-emerald-900 text-amber-50 font-mono text-sm tracking-wider uppercase font-bold rounded transition-colors"
        >
          ↻ play again
        </button>
      </div>
    </div>
  );
}
